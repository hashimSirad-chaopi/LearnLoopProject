<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Security</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Security</h1>
                <p>Protect the admin account with a second step when you sign in.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="sec-grid">

                        
                        <?php if($newCodes): ?>
                            <div class="ll-card">
                                <h3>Save your recovery codes</h3>
                                <div class="sec-warn">
                                    These are shown <strong>only once</strong>. Keep them somewhere safe (a password manager or printed). Each code works one time if you lose your phone.
                                </div>
                                <div class="sec-codes">
                                    <?php $__currentLoopData = $newCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><code><?php echo e($code); ?></code><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        
                        <div class="ll-card">
                            <div class="ll-row between">
                                <h3>Two-step verification</h3>
                                <span class="ll-badge <?php echo e($enabled ? 'completed' : 'pending'); ?>"><?php echo e($enabled ? 'On' : 'Off'); ?></span>
                            </div>

                            <?php if(! $enabled && ! $pending): ?>
                                <p>Right now anyone who learns your password can sign in. With two-step verification you also need the 6-digit code from an authenticator app on your phone (Google Authenticator, Microsoft Authenticator, Authy, 1Password...).</p>
                                <form method="POST" action="<?php echo e(route('admin.security.enable')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="settings-save-btn">Set up two-step verification</button>
                                </form>

                            <?php elseif($pending): ?>
                                <p><strong>Step 1.</strong> In your authenticator app choose “Add account”, then “Enter a setup key”. Use this key (spaces do not matter):</p>
                                <code class="sec-secret"><?php echo e($secret); ?></code>
                                <p class="ll-muted">Account name: <?php echo e(auth()->user()->email); ?> &middot; Type: time-based &middot; On a phone you can also <a href="<?php echo e($otpauth); ?>">tap here to open your authenticator app</a>.</p>

                                <p><strong>Step 2.</strong> Type the 6-digit code the app now shows to finish:</p>
                                <form method="POST" action="<?php echo e(route('admin.security.confirm')); ?>" class="sec-form">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" placeholder="123456" maxlength="7" required>
                                    <button type="submit" class="settings-save-btn">Turn on</button>
                                </form>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="sec-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php else: ?>
                                <div class="sec-ok">
                                    You are asked for a code each time you sign in. You have <strong><?php echo e($recoveryLeft); ?></strong> unused recovery <?php echo e(\Illuminate\Support\Str::plural('code', $recoveryLeft)); ?>.
                                </div>
                            <?php endif; ?>
                        </div>

                        
                        <?php if($enabled): ?>
                            <div class="ll-card">
                                <h3>Make new recovery codes</h3>
                                <p class="ll-muted">The old codes stop working. Needs your password and a current code.</p>
                                <form method="POST" action="<?php echo e(route('admin.security.codes')); ?>" class="sec-form">
                                    <?php echo csrf_field(); ?>
                                    <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                                    <input type="text" name="code" inputmode="numeric" placeholder="6-digit code" maxlength="7" required>
                                    <button type="submit" class="table-btn">Make new codes</button>
                                </form>
                            </div>

                            <div class="ll-card">
                                <h3>Turn off two-step verification</h3>
                                <p class="ll-muted">Not recommended. Needs your password and a current code.</p>
                                <form method="POST" action="<?php echo e(route('admin.security.disable')); ?>" class="sec-form" onsubmit="return confirm('Turn off two-step verification?');">
                                    <?php echo csrf_field(); ?>
                                    <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                                    <input type="text" name="code" inputmode="numeric" placeholder="6-digit code" maxlength="7" required>
                                    <button type="submit" class="delete-btn">Turn off</button>
                                </form>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="sec-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="sec-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>

                        
                        <div class="ll-card">
                            <h3>Other protection already in place</h3>
                            <ul class="ll-muted" style="padding-left:18px; line-height:1.8;">
                                <li>Admin login locks for a minute after 5 wrong tries.</li>
                                <li>Only active admin accounts can sign in to this panel.</li>
                                <li>App login and sign-up are rate limited.</li>
                                <li>Every admin action, sign-in and failed sign-in is recorded in <a href="<?php echo e(route('admin.activity')); ?>">Activity</a>.</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/security.blade.php ENDPATH**/ ?>