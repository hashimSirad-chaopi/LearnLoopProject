<button type="button" class="sidebar-toggle" aria-label="Open menu" onclick="document.body.classList.toggle('sidebar-open')">&#9776;</button>
<div class="sidebar-backdrop" onclick="document.body.classList.remove('sidebar-open')"></div>

<aside class="sidebar">
    <div class="sidebar-top">
        <div class="logo">LearnLoop</div>
        <nav class="sidebar-nav">
            <a href="<?php echo e(route('admin.home')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.home') ? 'active' : ''); ?>">Dashboard</a>
            <a href="<?php echo e(route('admin.users')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.users*') ? 'active' : ''); ?>">User Management</a>
            <a href="<?php echo e(route('admin.listings')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.listings*') ? 'active' : ''); ?>">Listings</a>
            <a href="<?php echo e(route('admin.comments')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.comments*') ? 'active' : ''); ?>">Comments</a>
            <?php $pendingLessonCount = \App\Models\Lesson::whereNotNull('author_id')->where('status', 'pending')->count(); ?>
            
            <a href="<?php echo e(route('admin.categories')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.categories*', 'admin.skills*', 'admin.lessons*') ? 'active' : ''); ?>">Categories
                <?php if($pendingLessonCount > 0): ?><span class="nav-count"><?php echo e($pendingLessonCount); ?></span><?php endif; ?>
            </a>
            <a href="<?php echo e(route('admin.professional')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.professional*') ? 'active' : ''); ?>">Professional Proofs
                <?php ($pendingProCount = \App\Models\ProfessionalVerification::where('status', 'in_review')->count()); ?>
                <?php if($pendingProCount > 0): ?><span class="nav-count"><?php echo e($pendingProCount); ?></span><?php endif; ?>
            </a>
            <a href="<?php echo e(route('admin.exchanges')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.exchanges*') ? 'active' : ''); ?>">Exchange Monitoring</a>
            <a href="<?php echo e(route('admin.reports')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.reports*') ? 'active' : ''); ?>">Reports</a>
            <a href="<?php echo e(route('admin.appeals')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.appeals*') ? 'active' : ''); ?>">Recovery Requests
                <?php ($pendingAppealCount = \App\Models\AccountAppeal::where('status', 'pending')->count()); ?>
                <?php if($pendingAppealCount > 0): ?><span class="nav-count"><?php echo e($pendingAppealCount); ?></span><?php endif; ?>
            </a>
            <a href="<?php echo e(route('admin.notifications')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.notifications*') ? 'active' : ''); ?>">Notifications
                <?php ($attentionTotal = \App\Support\AdminAlerts::total()); ?>
                <?php if($attentionTotal > 0): ?><span class="nav-count"><?php echo e($attentionTotal); ?></span><?php endif; ?>
            </a>
            <a href="<?php echo e(route('admin.activity')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.activity*') ? 'active' : ''); ?>">Activity Log</a>
            <a href="<?php echo e(route('admin.settings')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.settings*') ? 'active' : ''); ?>">Settings</a>
            <a href="<?php echo e(route('admin.security')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.security*') ? 'active' : ''); ?>">Security</a>
        </nav>
    </div>
    <div class="sidebar-bottom">
        <?php echo $__env->make('partials.logout-confirm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</aside>

<?php echo $__env->make('partials.live-updates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/partials/admin-sidebar.blade.php ENDPATH**/ ?>