<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - <?php echo e($user->name); ?>'s lessons</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .lr-avatar { border-radius: 11px; }
        .lr-avatar-lg { border-radius: 14px; }
    </style>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <style>
        .lr-profile { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
        .lr-avatar-lg { width: 56px; height: 56px; font-size: 22px; }
    </style>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($user->name); ?></h1>
                <p><?php echo e($user->email); ?> &middot; <?php echo e($totals['all']); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $totals['all'])); ?> written</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-card lr-profile">
                        <div class="lr-member" style="gap:14px;">
                            <?php echo $__env->make('partials.avatar', ['user' => $user, 'class' => 'lr-avatar lr-avatar-lg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <span class="lr-member-text">
                                <strong style="font-size:17px;"><?php echo e($user->name); ?></strong>
                                <small style="max-width:none;"><?php echo e($user->email); ?><?php if($totals['last']): ?> &middot; last lesson <?php echo e(\Illuminate\Support\Carbon::parse($totals['last'])->diffForHumans()); ?><?php endif; ?></small>
                            </span>
                        </div>
                        <div class="ll-row">
                            <?php if($user->status === 'suspended'): ?><span class="ll-badge rejected">Suspended</span><?php endif; ?>
                            <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="table-btn ll-link">View profile &rsaquo;</a>
                        </div>
                    </div>

                    <div class="ll-row between">
                        <a href="<?php echo e(route('admin.lessons')); ?>" class="table-btn ll-link">&larr; Users</a>
                        <div class="ll-row">
                            <span class="ll-badge pending">Pending <?php echo e($totals['pending']); ?></span>
                            <span class="ll-badge published">Published <?php echo e($totals['published']); ?></span>
                            <span class="ll-badge rejected">Need change <?php echo e($totals['rejected']); ?></span>
                        </div>
                    </div>

                    
                    <div class="ll-toolbar">
                        <form method="GET" action="<?php echo e(route('admin.lessons.member', $user)); ?>" class="ll-search">
                            <input type="text" inputmode="search" name="search" value="<?php echo e($search); ?>" placeholder="Search category, skill or lesson" aria-label="Search this member's lessons">
                            <button type="submit" class="table-btn">Search</button>
                            <?php if($search !== ''): ?>
                                <a href="<?php echo e(route('admin.lessons.member', $user)); ?>" class="table-btn ll-link">Clear</a>
                            <?php endif; ?>
                        </form>
                    </div>

                    <?php if($search !== ''): ?>
                        <span class="ll-muted">Showing results for &ldquo;<?php echo e($search); ?>&rdquo;</span>
                    <?php endif; ?>

                    
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="ll-card">
                            <h3 class="lr-category"><?php echo e($categoryName); ?></h3>
                            <div class="lr-list">
                                <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('admin.lessons.member.skill', [$user, $row['skill']])); ?>" class="lr-skill-row">
                                        <span class="lr-skill-icon"><?php echo e($row['skill']->icon); ?></span>
                                        <span class="lr-grow">
                                            <strong><?php echo e($row['skill']->title); ?></strong>
                                            <small>
                                                <?php echo e($row['total']); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $row['total'])); ?>

                                                <?php if($row['matches']->isNotEmpty()): ?>
                                                    &middot; matches: <?php echo e($row['matches']->implode(', ')); ?>

                                                <?php endif; ?>
                                            </small>
                                        </span>
                                        <?php if($row['pending'] > 0): ?><span class="ll-badge pending"><?php echo e($row['pending']); ?> pending</span><?php endif; ?>
                                        <?php if($row['published'] > 0): ?><span class="ll-badge published"><?php echo e($row['published']); ?> published</span><?php endif; ?>
                                        <?php if($row['rejected'] > 0): ?><span class="ll-badge rejected"><?php echo e($row['rejected']); ?> need change</span><?php endif; ?>
                                        <span class="lr-chevron" aria-hidden="true">&rsaquo;</span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ll-card"><p class="ll-muted">No category, skill or lesson matches &ldquo;<?php echo e($search); ?>&rdquo;.</p></div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/lessons/member.blade.php ENDPATH**/ ?>