<?php ($editing = $skill->exists); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - <?php echo e($editing ? 'Edit' : 'Add'); ?> Skill</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($editing ? 'Edit Skill' : 'Add Skill'); ?></h1>
                <p>A skill is one course in the Learn tab, such as "Intro to Python".</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.crumbs', ['items' => $editing
                        ? [['Skills & lessons', route('admin.skills')], [$skill->title, route('admin.skills.show', $skill)], ['Edit']]
                        : [['Skills & lessons', route('admin.skills')], ['New skill']]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <form class="ll-card ll-form" method="POST"
                          action="<?php echo e($editing ? route('admin.skills.update', $skill) : route('admin.skills.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                        <div>
                            <label for="title">Title</label>
                            <input id="title" name="title" type="text" value="<?php echo e(old('title', $skill->title)); ?>" required>
                        </div>

                        <div>
                            <label for="category_id">Category</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Choose a category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e((string) old('category_id', $skill->category_id) === (string) $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p class="ll-muted">Listings use the category of their skill, so members never pick it separately.</p>
                        </div>

                        <div>
                            <label for="icon">Icon (one emoji)</label>
                            <input id="icon" name="icon" type="text" maxlength="16" value="<?php echo e(old('icon', $skill->icon)); ?>">
                        </div>

                        <div>
                            <label for="description">Description</label>
                            <textarea id="description" name="description" rows="3"><?php echo e(old('description', $skill->description)); ?></textarea>
                        </div>

                        <div>
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="active" <?php echo e(old('status', $skill->status) === 'active' ? 'selected' : ''); ?>>Active</option>
                                <option value="inactive" <?php echo e(old('status', $skill->status) === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                            </select>
                        </div>

                        <div class="settings-actions">
                            <a href="<?php echo e($editing ? route('admin.skills.show', $skill) : route('admin.skills')); ?>" class="table-btn ll-link">Cancel</a>
                            <button type="submit" class="settings-save-btn"><?php echo e($editing ? 'Save Skill' : 'Create Skill'); ?></button>
                        </div>
                    </form>

                    <?php if($editing): ?>
                        <form method="POST" action="<?php echo e(route('admin.skills.delete', $skill)); ?>"
                              onsubmit="return confirm('Delete this skill with all its levels, lessons and quizzes?');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn">Delete Skill</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/skills/form.blade.php ENDPATH**/ ?>