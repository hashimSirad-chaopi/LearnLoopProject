<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>LearnLoop - Listings</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>

<div class="admin-container">

    <!-- =========================================
         SIDEBAR
    ========================================== -->
       <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <!-- =========================================
         MAIN CONTENT
    ========================================== -->
    <main class="main-content" data-live>

        <!-- FIXED HEADER -->
        <header class="top-header">

            <div class="header-left">

                <span class="header-label">
                    ADMIN PANEL
                </span>

                <h1>
                    Listings
                </h1>

                <p>
                    Review and manage listings posted by LearnLoop users.
                </p>

            </div>

        </header>


        <!-- =====================================
             LISTINGS PAGE
        ====================================== -->
        <section class="listing-page">

            <!-- TOOLBAR -->
            <div class="listing-toolbar">

                <div class="dashboard-heading">

                    <div>

                        <span class="section-label">
                            LISTINGS
                        </span>

                        <h2>
                            All Listings
                        </h2>

                        <p>
                            Review, disable, or remove user-created listings.
                        </p>

                    </div>

                </div>


                <!-- SEARCH -->
                <!-- SEARCH -->
<form method="GET" action="<?php echo e(route('admin.listings')); ?>" style="display:flex; gap:10px; flex:1; align-items:center;">
    <input
        type="search"
        name="search"
        value="<?php echo e($search); ?>"
        class="listing-search"
        placeholder="Search listings..."
        aria-label="Search listings"
    >
    <select name="status" class="sort-select" aria-label="Filter by status" onchange="this.form.submit()">
        <option value="all" <?php if($status === 'all'): echo 'selected'; endif; ?>>All statuses</option>
        <option value="pending" <?php if($status === 'pending'): echo 'selected'; endif; ?>>Pending approval</option>
        <option value="active" <?php if($status === 'active'): echo 'selected'; endif; ?>>Active</option>
        <option value="inactive" <?php if($status === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
    </select>
    <select name="sort" class="sort-select" aria-label="Sort listings" onchange="this.form.submit()">
        <option value="newest" <?php if($sort === 'newest'): echo 'selected'; endif; ?>>Newest first</option>
        <option value="oldest" <?php if($sort === 'oldest'): echo 'selected'; endif; ?>>Oldest first</option>
        <option value="title" <?php if($sort === 'title'): echo 'selected'; endif; ?>>Title A to Z</option>
        <option value="status" <?php if($sort === 'status'): echo 'selected'; endif; ?>>Pending first</option>
    </select>
    <button type="submit" class="table-btn">Search</button>
</form>

<a href="<?php echo e(route('admin.listings.create')); ?>" class="settings-save-btn" style="text-decoration:none;">+ Add Listing</a>
                
            </div>


            <!-- =================================
                 SCROLLABLE LISTINGS
            ================================== -->
            <div class="listings-scroll-area">

                <div class="listings-feed">

                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php if($listings->isNotEmpty()): ?>
                        <form id="bulk-listings" method="POST" action="<?php echo e(route('admin.listings.bulk')); ?>" class="bulk-bar">
                            <?php echo csrf_field(); ?>
                            <label class="bulk-all"><input type="checkbox" data-select-all="bulk-listings"> Select all on this page (<?php echo e($listings->count()); ?>)</label>
                            <span class="bulk-count"></span>
                            <span class="bulk-actions">
                                <button type="submit" name="bulk" value="enable" class="table-btn" onclick="return confirm('Approve / enable the selected listings?');">Approve / enable selected</button>
                                <button type="submit" name="bulk" value="disable" class="table-btn" onclick="return confirm('Disable the selected listings?');">Disable selected</button>
                            </span>
                        </form>
                    <?php endif; ?>


                    <!-- =================================
                         LISTING 1
                    ================================== -->
                   <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="listing-post">
        <div class="listing-post-header">
            <input type="checkbox" name="ids[]" value="<?php echo e($listing->id); ?>" form="bulk-listings" class="bulk-check" aria-label="Select listing">
            <div class="listing-user">
                <?php echo $__env->make('partials.avatar', ['user' => $listing->user, 'class' => 'listing-avatar', 'letters' => 2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div>
                    <h3><?php echo e($listing->user->name); ?></h3>
                    <span><?php echo e($listing->category?->name ?? 'Uncategorized'); ?></span>
                </div>
            </div>
            <span class="listing-status <?php echo e($listing->status); ?>"><?php echo e(ucfirst($listing->status)); ?></span>
        </div>

        <div class="listing-content">
            <span class="listing-category">
    <?php echo e($listing->category?->name ?? 'Uncategorized'); ?>

</span>
            <h2><?php echo e($listing->title); ?></h2>
            <?php if($listing->wantsSkill || $listing->offersSkill): ?>
                <p style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
                    <span class="ll-badge">Offers: <?php echo e($listing->offersSkill?->title ?? 'Nothing yet'); ?></span>
                    <span class="ll-badge">Wants: <?php echo e($listing->wantsSkill?->title ?? '—'); ?></span>
                    <?php if($listing->wants_level): ?><span class="ll-badge">Level: <?php echo e(ucfirst($listing->wants_level)); ?><?php if($listing->wants_level === 'professional'): ?> · paid<?php echo e($listing->budget ? ' · ₱'.number_format($listing->budget).' per lesson' : ' · budget negotiable'); ?><?php endif; ?></span><?php endif; ?>
                    <?php if($listing->isLearnerOnly()): ?><span class="ll-badge learner-only">Learner only</span><?php endif; ?>
                </p>
            <?php endif; ?>
            <p><?php echo e($listing->description); ?></p>
        </div>

        <div class="listing-footer">
            <span class="listing-date">Posted <?php echo e($listing->created_at->diffForHumans()); ?></span>
            <div class="listing-actions">
                <a href="<?php echo e(route('admin.listings.edit', $listing->id)); ?>" class="table-btn" style="text-decoration:none;">Edit</a>
                <?php if($listing->status !== 'active'): ?>
    <form method="POST" action="<?php echo e(route('admin.listings.enable', $listing->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <button type="submit" class="disable-btn"><?php echo e($listing->status === 'pending' ? 'Approve' : 'Enable'); ?></button>
    </form>
<?php endif; ?>
<?php if($listing->status !== 'inactive'): ?>
    <form method="POST" action="<?php echo e(route('admin.listings.disable', $listing->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <button type="submit" class="disable-btn">Disable</button>
    </form>
<?php endif; ?>
                <form method="POST" action="<?php echo e(route('admin.listings.delete', $listing->id)); ?>" onsubmit="return confirm('Delete this listing?');">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="delete-btn">Delete</button>
                </form>
            </div>
        </div>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No listings found.</p>
<?php endif; ?>

                    <?php echo e($listings->links('vendor.pagination.admin')); ?>


                </div>

            </div>

        </section>

    </main>

</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/listing.blade.php ENDPATH**/ ?>