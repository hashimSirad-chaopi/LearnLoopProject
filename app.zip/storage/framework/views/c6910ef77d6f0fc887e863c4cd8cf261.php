<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Exchange Details</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Exchange #EX-<?php echo e(str_pad($exchange->id, 3, '0', STR_PAD_LEFT)); ?></h1>
                <p>Review and manage this exchange.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-row between">
                        <a href="<?php echo e(route('admin.exchanges')); ?>" class="table-btn ll-link">← All exchanges</a>
                        <div class="ll-actions">
                            <?php if($exchange->isLearnerOnly()): ?><span class="ll-badge learner-only">Learner only</span><?php endif; ?>
                            <span class="ll-badge <?php echo e($exchange->status); ?>"><?php echo e(ucfirst($exchange->status)); ?></span>
                        </div>
                    </div>

                    <?php if($exchange->status === 'disputed'): ?>
                        <div class="ll-note danger">
                            <strong>Dispute<?php echo e($exchange->disputedBy ? ' filed by ' . $exchange->disputedBy->name : ''); ?><?php echo e($exchange->disputed_at ? ' ' . $exchange->disputed_at->diffForHumans() : ''); ?>:</strong>
                            <?php echo e($exchange->dispute_reason ?: 'No reason was recorded.'); ?>

                            <br>Read the evidence below, then set the outcome under “Decision”. Both members are notified in the app.
                        </div>
                    <?php elseif($exchange->resolved_at): ?>
                        <div class="ll-note">Dispute resolved <?php echo e($exchange->resolved_at->diffForHumans()); ?>.</div>
                    <?php endif; ?>

                    <div class="ll-card">
                        <h3>Who and what</h3>
                        <div class="ll-stat" style="margin-top:8px;">
                            <div><span>Provider (teaches)</span><strong><?php echo e($exchange->provider->name ?? 'N/A'); ?></strong></div>
                            <div><span>Learner</span><strong><?php echo e($exchange->learner->name ?? 'N/A'); ?></strong></div>
                            <div><span>Provider teaches</span><strong><?php echo e($exchange->skill_offered ?: '—'); ?></strong></div>
                            <div><span>Learner teaches back</span><strong><?php echo e($exchange->skill_wanted ?: 'Nothing (learner only)'); ?></strong></div>
                        </div>
                    </div>

                    <?php if($exchange->exchangeLessons->isNotEmpty()): ?>
                        <div class="ll-card">
                            <h3>Lessons written inside this exchange</h3>
                            <p class="ll-muted">Private lessons a coach wrote for their partner. They are not reviewed, so read them here if there is a complaint.</p>
                            <?php $__currentLoopData = $exchange->exchangeLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="ll-question">
                                    <strong><?php echo e($extra->title); ?></strong>
                                    <div class="ll-muted">by <?php echo e($extra->author?->name ?? 'Deleted user'); ?> · <?php echo e($extra->created_at->diffForHumans()); ?></div>
                                    <p class="ll-lesson-text" style="margin-top:8px;"><?php echo e($extra->content); ?></p>
                                    <?php $__currentLoopData = ($extra->questions ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="margin-top:8px;">
                                            <strong><?php echo e($loop->iteration); ?>. <?php echo e($q['text'] ?? ''); ?></strong>
                                            <?php $__currentLoopData = ($q['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oi => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="ll-option <?php echo e((int) ($q['correct'] ?? -1) === $oi ? 'correct' : ''); ?>">
                                                    <span class="mark"><?php echo e((int) ($q['correct'] ?? -1) === $oi ? '✓' : '•'); ?></span><span><?php echo e($text); ?></span>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="ll-card">
                        <h3>Sessions</h3>
                        <?php $__empty_1 = true; $__currentLoopData = $exchange->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="ll-lesson">
                                <div>
                                    <strong><?php echo e(\Illuminate\Support\Carbon::parse($schedule->date)->format('M j, Y')); ?> · <?php echo e($schedule->time_start); ?>–<?php echo e($schedule->time_end); ?></strong>
                                    <div class="ll-muted"><?php echo e($schedule->location ?: 'No location'); ?><?php echo e($schedule->notes ? ' · ' . $schedule->notes : ''); ?></div>
                                </div>
                                <span class="ll-badge <?php echo e($schedule->status === 'confirmed' ? 'ongoing' : $schedule->status); ?>"><?php echo e(ucfirst($schedule->status)); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="ll-muted">No sessions scheduled.</p>
                        <?php endif; ?>
                    </div>

                    <div class="ll-card">
                        <h3>Ratings</h3>
                        <?php $__empty_1 = true; $__currentLoopData = $exchange->ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <p><strong><?php echo e($rating->rater?->name ?? 'Deleted user'); ?></strong> gave <?php echo e($rating->rating); ?>★<?php echo e($rating->comment ? ' — “' . $rating->comment . '”' : ''); ?></p>
                            <?php echo $__env->make('admin.partials.rating-proof', ['rating' => $rating], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="ll-muted">Nobody has rated this exchange yet.</p>
                        <?php endif; ?>
                    </div>

                    <div class="ll-card">
                        <h3>Messages in this exchange</h3>
                        <?php $__empty_1 = true; $__currentLoopData = $exchange->messages->sortBy('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <p><strong><?php echo e($message->sender?->name ?? 'Deleted user'); ?></strong> <span class="ll-muted"><?php echo e($message->created_at->format('M j, g:i A')); ?></span><br><?php echo e($message->message_text); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="ll-muted">No messages are linked to this exchange.</p>
                        <?php endif; ?>
                    </div>

                    <div class="ll-card">
                        <h3>Decision</h3>
                        <form class="ll-form" method="POST" action="<?php echo e(route('admin.exchanges.update', $exchange->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div>
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <?php $__currentLoopData = ['pending' => 'Pending', 'ongoing' => 'Ongoing', 'completed' => 'Completed', 'disputed' => 'Disputed', 'cancelled' => 'Cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php echo e(old('status', $exchange->status) === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="admin_notes">Admin note (members see this when you resolve a dispute)</label>
                                <textarea id="admin_notes" name="admin_notes" rows="3"><?php echo e(old('admin_notes', $exchange->admin_notes)); ?></textarea>
                            </div>
                            <div class="settings-actions">
                                <button type="submit" class="settings-save-btn">Update Exchange</button>
                            </div>
                        </form>

                        <form method="POST" action="<?php echo e(route('admin.exchanges.delete', $exchange->id)); ?>" onsubmit="return confirm('Delete this exchange?');" style="margin-top:15px;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn">Delete Exchange</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/exchanges-show.blade.php ENDPATH**/ ?>