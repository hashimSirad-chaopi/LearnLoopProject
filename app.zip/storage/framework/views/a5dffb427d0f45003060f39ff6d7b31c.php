<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Edit User</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

      <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Edit User</h1>
                <p>Update this user's account details.</p>
            </div>
        </header>

        <section class="users-page">
            <form class="settings-form" method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="settings-field">
                    <label for="name">Name</label>
                    <input id="name" name="name" type="text" value="<?php echo e(old('name', $user->name)); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:red;font-size:13px;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="settings-field">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" value="<?php echo e(old('email', $user->email)); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:red;font-size:13px;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="settings-field">
                    <label for="password">Reset Password (optional)</label>
                    <input id="password" name="password" type="password" minlength="8" placeholder="Leave blank to keep current password (min 8 characters)">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:red;font-size:13px;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="settings-field">
                    <label for="role">Role</label>
                    <select id="role" name="role">
                        <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>User</option>
                        <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                    </select>
                </div>

                <div class="settings-actions">
                    <a href="<?php echo e(route('admin.users')); ?>" class="table-btn">Cancel</a>
                    <button type="submit" class="settings-save-btn">Save Changes</button>
                </div>
            </form>
        </section>
    </main>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/users-edit.blade.php ENDPATH**/ ?>