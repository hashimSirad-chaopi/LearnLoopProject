<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - <?php echo e($skill->title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($skill->icon); ?> <?php echo e($skill->title); ?></h1>
                <p><?php echo e($skill->category?->name ?? 'No category'); ?> &middot; <?php echo e(ucfirst($skill->status)); ?></p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.catalog-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php echo $__env->make('partials.crumbs', ['items' => array_values(array_filter([
                        ['Skills & lessons', route('admin.skills')],
                        $skill->category ? [$skill->category->name, route('admin.skills', ['category' => $skill->category_id])] : null,
                        [$skill->title],
                    ]))], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php ($catalogLessonCount = $skill->levels->sum(fn ($l) => $l->lessons->whereNull('author_id')->count())); ?>
                    <?php ($questionCount = $skill->levels->sum(fn ($l) => $l->lessons->whereNull('author_id')->sum(fn ($x) => $x->questions->count()))); ?>

                    <div class="ll-card">
                        <div class="ll-row between">
                            <div class="ll-counts">
                                <span><strong><?php echo e($catalogLessonCount); ?></strong> <?php echo e(\Illuminate\Support\Str::plural('lesson', $catalogLessonCount)); ?></span>
                                <span><strong><?php echo e($questionCount); ?></strong> quiz <?php echo e(\Illuminate\Support\Str::plural('question', $questionCount)); ?></span>
                                <span><strong><?php echo e($skill->levels->count()); ?></strong> of <?php echo e(count($levelNames)); ?> levels used</span>
                                <span><strong><?php echo e($memberLessons->count()); ?></strong> by members</span>
                            </div>
                            <div class="ll-actions">
                                <a href="<?php echo e(route('admin.skills.edit', $skill)); ?>" class="table-btn ll-link">Edit skill</a>
                                <a href="<?php echo e(route('admin.skills.lessons.create', $skill)); ?>" class="settings-save-btn ll-link">+ Add lesson</a>
                            </div>
                        </div>
                        <?php if($skill->description): ?><p style="margin-top:10px;"><?php echo e($skill->description); ?></p><?php endif; ?>
                        <p class="ll-muted">Learners take lessons in order, easiest level first. A lesson unlocks when the previous quiz is passed.</p>
                    </div>

                    <?php $__currentLoopData = $levelNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($level = $skill->levels->firstWhere('name', $name)); ?>
                        <?php ($catalogLessons = $level ? $level->lessons->whereNull('author_id')->sortBy('order')->values() : collect()); ?>

                        <div class="ll-card ll-level-block">
                            <div class="ll-row between">
                                <div class="ll-row">
                                    <span class="ll-level-pill <?php echo e($name); ?>"><?php echo e(ucfirst($name)); ?></span>
                                    <span class="ll-muted"><?php echo e($catalogLessons->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $catalogLessons->count())); ?></span>
                                </div>
                                <a href="<?php echo e(route('admin.skills.lessons.create', [$skill, 'level' => $name])); ?>" class="table-btn ll-link">+ Add <?php echo e($name); ?> lesson</a>
                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $catalogLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ll-lesson">
                                    <div>
                                        <strong><?php echo e($loop->iteration); ?>. <?php echo e($lesson->title); ?></strong>
                                        <?php if(($lesson->content_type ?? 'text') !== 'text'): ?><span class="ll-badge"><?php echo e(ucfirst($lesson->content_type)); ?></span><?php endif; ?>
                                        <div class="ll-muted">
                                            <?php echo e($lesson->questions->count()); ?> quiz <?php echo e(\Illuminate\Support\Str::plural('question', $lesson->questions->count())); ?>

                                            <?php if($lesson->questions->isEmpty()): ?><span class="ll-badge pending">No quiz</span><?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="ll-actions">
                                        <a href="<?php echo e(route('admin.skills.lessons.edit', [$skill, $lesson])); ?>" class="table-btn ll-link">Edit</a>
                                        <form method="POST" action="<?php echo e(route('admin.skills.lessons.delete', [$skill, $lesson])); ?>" onsubmit="return confirm('Delete this lesson and its quiz?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="delete-btn">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted ll-empty-level">No <?php echo e($name); ?> lessons yet.</p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($memberLessons->isNotEmpty()): ?>
                        <div class="ll-card">
                            <h3>Written by members</h3>
                            <p class="ll-muted">Reviewed in the Member lessons tab. Only published ones are shown to learners.</p>
                            <table class="ll-table">
                                <thead><tr><th>Lesson</th><th>Author</th><th>Status</th><th></th></tr></thead>
                                <tbody>
                                <?php $__currentLoopData = $memberLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($lesson->title); ?></td>
                                        <td><?php echo e($lesson->author?->name ?? 'Deleted user'); ?></td>
                                        <td><span class="ll-badge <?php echo e($lesson->status); ?>"><?php echo e($lesson->status === 'rejected' ? 'Needs changes' : ucfirst($lesson->status)); ?></span></td>
                                        <td><a href="<?php echo e(route('admin.lessons.show', $lesson)); ?>" class="table-btn ll-link">Open</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/skills/show.blade.php ENDPATH**/ ?>