<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Review Lesson</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .lr-avatar { border-radius: 11px; }
        .lr-avatar-lg { border-radius: 14px; }
    </style>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($lesson->title); ?></h1>
                <p><?php echo e($skill->icon); ?> <?php echo e($skill->title); ?> · <?php echo e(ucfirst($lesson->skillLevel->name)); ?> level</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-row between">
                        <a href="<?php echo e($back); ?>" class="table-btn ll-link">← Back</a>
                        <span class="ll-badge <?php echo e($lesson->status); ?>"><?php echo e($lesson->status === 'rejected' ? 'Needs changes' : ucfirst($lesson->status)); ?></span>
                    </div>

                    <div class="ll-card">
                        <h3>Author</h3>
                        <?php if($lesson->author): ?>
                            <a href="<?php echo e(route('admin.lessons.member', $lesson->author)); ?>" class="lr-member" style="margin-top:8px;">
                                <?php echo $__env->make('partials.avatar', ['user' => $lesson->author, 'class' => 'lr-avatar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <span class="lr-member-text"><strong><?php echo e($lesson->author->name); ?></strong><small><?php echo e($lesson->author->email); ?></small></span>
                            </a>
                        <?php endif; ?>
                        <div class="ll-stat" style="margin-top:8px;">
                            <div><span>Name</span><strong><?php echo e($lesson->author?->name ?? 'Deleted user'); ?></strong></div>
                            <div><span>Approved in <?php echo e($skill->title); ?></span><strong><?php echo e($trust['approved']); ?> / <?php echo e(\App\Support\AuthorTrust::APPROVALS_NEEDED); ?></strong></div>
                            <div><span>Ratings</span><strong><?php echo e($trust['rating_count']); ?><?php echo e($trust['rating_count'] ? ' · ' . $trust['average'] . '★' : ''); ?></strong></div>
                            <div><span>Trusted</span><strong><?php echo e($trust['is_trusted'] ? 'Yes' : 'Not yet'); ?></strong></div>
                        </div>
                        <p class="ll-muted" style="margin-top:10px;">
                            An author becomes trusted in a skill after <?php echo e(\App\Support\AuthorTrust::APPROVALS_NEEDED); ?> lessons you approved by hand and
                            <?php echo e(\App\Support\AuthorTrust::RATINGS_NEEDED); ?>+ learner ratings averaging <?php echo e(number_format(\App\Support\AuthorTrust::MIN_RATING, 1)); ?> or better.
                            Trusted authors publish without waiting for you.
                        </p>
                    </div>

                    <div class="ll-card">
                        <h3>Lesson text</h3>
                        <?php if($lesson->attachment_path): ?>
                            <p><a href="<?php echo e($lesson->attachment_url); ?>" target="_blank" rel="noopener"><?php echo e(ucfirst($lesson->content_type)); ?>: <?php echo e($lesson->attachment_name ?: 'open'); ?></a></p>
                        <?php endif; ?>
                        <p class="ll-lesson-text"><?php echo e($lesson->content); ?></p>
                    </div>

                    <div class="ll-card">
                        <h3>Quiz (<?php echo e($lesson->questions->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('question', $lesson->questions->count())); ?>)</h3>
                        <?php $__currentLoopData = $lesson->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ll-question">
                                <?php $qm = $question->mediaPayload(); ?>
                                <?php if($qm['media_url']): ?>
                                    <div style="margin-bottom:6px;">
                                        <?php if($qm['media_type'] === 'photo'): ?> <img src="<?php echo e($qm['media_url']); ?>" alt="" style="max-height:140px;border-radius:8px;">
                                        <?php elseif($qm['media_type'] === 'video'): ?> <video src="<?php echo e($qm['media_url']); ?>" controls style="max-height:160px;border-radius:8px;"></video>
                                        <?php else: ?> <audio src="<?php echo e($qm['media_url']); ?>" controls></audio>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <strong><?php echo e($loop->iteration); ?>. <?php echo e($question->question_text); ?></strong>
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="ll-option <?php echo e($option->is_correct ? 'correct' : ''); ?>">
                                        <span class="mark"><?php echo e($option->is_correct ? '✓' : '•'); ?></span>
                                        <span><?php echo e($option->option_text); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p class="ll-muted">The admin cannot be an expert in every skill. Check for safety, format and obvious mistakes: every question has four options and one correct answer.</p>
                    </div>

                    <?php if($ratingAverage !== null): ?>
                        <div class="ll-card">
                            <h3>Learner rating</h3>
                            <p><?php echo e($ratingAverage); ?>★ from <?php echo e($lesson->ratings->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('learner', $lesson->ratings->count())); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($lesson->status === 'rejected' && $lesson->rejection_reason): ?>
                        <div class="ll-note danger"><strong>Changes requested:</strong> <?php echo e($lesson->rejection_reason); ?></div>
                    <?php endif; ?>

                    <?php if($lesson->status === 'published'): ?>
                        <div class="ll-note">
                            <?php if($lesson->approver): ?>
                                Approved by <?php echo e($lesson->approver->name); ?><?php echo e($lesson->reviewed_at ? ' ' . $lesson->reviewed_at->diffForHumans() : ''); ?>. Counts toward the author's trust.
                            <?php else: ?>
                                Published automatically because the author is trusted in this skill. It does not count toward trust.
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="ll-card">
                        <h3>Decision</h3>
                        <div class="ll-actions" style="margin-bottom:14px;">
                            <?php if($lesson->status !== 'published' || ! $lesson->approver): ?>
                                <form method="POST" action="<?php echo e(route('admin.lessons.approve', $lesson)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="back" value="<?php echo e($back); ?>">
                                    <button type="submit" class="settings-save-btn"><?php echo e($lesson->status === 'published' ? 'Mark as approved by me' : 'Approve and publish'); ?></button>
                                </form>
                            <?php endif; ?>
                        </div>

                        <form method="POST" action="<?php echo e(route('admin.lessons.reject', $lesson)); ?>" class="ll-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="back" value="<?php echo e($back); ?>">
                            <div>
                                <label for="rejection_reason">Ask for changes (the author sees this in the app)</label>
                                <textarea id="rejection_reason" name="rejection_reason" rows="3" placeholder="Say what to fix, then they can resubmit."><?php echo e(old('rejection_reason', $lesson->rejection_reason)); ?></textarea>
                            </div>
                            <div><button type="submit" class="disable-btn">Send back for changes</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/lessons/show.blade.php ENDPATH**/ ?>