<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - <?php echo e($user->name); ?> &middot; <?php echo e($skill->title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($skill->icon); ?> <?php echo e($skill->title); ?></h1>
                <p><?php echo e($skill->category?->name ?? 'Uncategorized'); ?> &middot; lessons written by <?php echo e($user->name); ?></p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-row">
                        <a href="<?php echo e(route('admin.lessons')); ?>" class="table-btn ll-link">Users</a>
                        <span class="ll-muted">&rsaquo;</span>
                        <a href="<?php echo e(route('admin.lessons.member', $user)); ?>" class="table-btn ll-link"><?php echo e($user->name); ?></a>
                        <span class="ll-muted">&rsaquo;</span>
                        <strong class="ll-muted"><?php echo e($skill->category?->name ?? 'Uncategorized'); ?> / <?php echo e($skill->title); ?></strong>
                    </div>

                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $levelName => $lessons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ll-card">
                            <h3 class="lr-category"><?php echo e(ucfirst($levelName)); ?></h3>
                            <p class="ll-muted">
                                <?php echo e($lessons->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $lessons->count())); ?>

                                &middot; numbered in the order learners get them
                                <?php if($lessons->count() > 1): ?>
                                    &middot; use &#9650; &#9660; to rearrange (the change also shows in <?php echo e($user->name); ?>'s app)
                                <?php endif; ?>
                            </p>

                            <div class="lr-list">
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="lr-lesson-row" id="lesson-<?php echo e($lesson->id); ?>">
                                        <span class="lr-num"><?php echo e($loop->iteration); ?></span>
                                        <span class="lr-grow">
                                            <strong><?php echo e($lesson->title); ?></strong>
                                            <small>
                                                Submitted <?php echo e($lesson->created_at->diffForHumans()); ?>

                                                <?php if($lesson->ratings_count > 0): ?>
                                                    &middot; <?php echo e(number_format($lesson->ratings_avg_stars, 1)); ?>&#9733; from <?php echo e($lesson->ratings_count); ?>

                                                <?php endif; ?>
                                            </small>
                                        </span>
                                        <span class="ll-badge <?php echo e($lesson->status); ?>"><?php echo e($lesson->status === 'rejected' ? 'Needs changes' : ucfirst($lesson->status)); ?></span>
                                        <?php if($lesson->status === 'published' && ! $lesson->approved_by): ?>
                                            <span class="ll-badge trusted" title="Published automatically because the author is trusted in this skill. Does not count toward trust.">Auto</span>
                                        <?php endif; ?>
                                        <?php if($lessons->count() > 1): ?>
                                            <form method="POST" action="<?php echo e(route('admin.lessons.member.skill.move', [$user, $skill])); ?>" class="lr-move-form">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="lesson_id" value="<?php echo e($lesson->id); ?>">
                                                <button type="submit" name="direction" value="up" class="lr-move" title="Move up" aria-label="Move up" <?php if($loop->first): echo 'disabled'; endif; ?>>&#9650;</button>
                                                <button type="submit" name="direction" value="down" class="lr-move" title="Move down" aria-label="Move down" <?php if($loop->last): echo 'disabled'; endif; ?>>&#9660;</button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('admin.lessons.show', $lesson)); ?>" class="table-btn ll-link"><?php echo e($lesson->status === 'pending' ? 'Review' : 'View'); ?></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/lessons/member-skill.blade.php ENDPATH**/ ?>