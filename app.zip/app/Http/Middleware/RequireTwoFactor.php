<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * An admin who turned on two-step verification must enter a code once per
 * login session before reaching any admin page. Admins who did not turn it
 * on are not affected.
 */
class RequireTwoFactor
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user
            && $user->role === 'admin'
            && $user->two_factor_confirmed_at
            && $request->session()->get('two_factor_passed_for') !== $user->id) {

            if ($request->isMethod('GET')) {
                $request->session()->put('two_factor_intended', $request->fullUrl());
            }

            return redirect()->route('admin.two-factor');
        }

        return $next($request);
    }
}
