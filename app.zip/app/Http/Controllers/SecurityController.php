<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Support\Totp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/** Admin > Security: turn two-step verification on or off, and manage recovery codes. */
class SecurityController extends Controller
{
    public function show(Request $request)
    {
        $user = $request->user();
        $pending = ! $user->two_factor_confirmed_at && $user->two_factor_secret;

        return view('admin.security', [
            'enabled' => (bool) $user->two_factor_confirmed_at,
            'pending' => $pending,
            'secret' => $pending ? Totp::pretty($user->two_factor_secret) : null,
            'otpauth' => $pending ? Totp::uri($user->two_factor_secret, $user->email) : null,
            'recoveryLeft' => count($user->two_factor_recovery_codes ?? []),
            // Shown once, right after turning it on or regenerating.
            'newCodes' => session('new_recovery_codes'),
        ]);
    }

    /** Step 1: make a secret and show it. Not active until a code is confirmed. */
    public function enable(Request $request)
    {
        $user = $request->user();

        if (! $user->two_factor_confirmed_at) {
            $user->forceFill(['two_factor_secret' => Totp::generateSecret(), 'two_factor_recovery_codes' => null])->save();
            ActivityLog::record('admin.2fa_setup_started', 'Started setting up two-step verification');
        }

        return redirect()->route('admin.security');
    }

    /** Step 2: prove the app works by typing the current code. */
    public function confirm(Request $request)
    {
        $user = $request->user();
        $request->validate(['code' => 'required|string|max:12']);

        if (! $user->two_factor_secret || ! Totp::verify($user->two_factor_secret, $request->code)) {
            return back()->withErrors(['code' => 'That code did not match. Check the time on your phone and try again.']);
        }

        $codes = $this->makeRecoveryCodes();
        $user->forceFill(['two_factor_confirmed_at' => now(), 'two_factor_recovery_codes' => $codes])->save();
        $request->session()->put('two_factor_passed_for', $user->id);

        ActivityLog::record('admin.2fa_enabled', 'Turned on two-step verification');

        return redirect()->route('admin.security')->with('new_recovery_codes', $codes)->with('success', 'Two-step verification is on.');
    }

    public function regenerateCodes(Request $request)
    {
        $user = $request->user();
        if ($error = $this->checkPasswordAndCode($request)) {
            return back()->withErrors($error);
        }

        $codes = $this->makeRecoveryCodes();
        $user->forceFill(['two_factor_recovery_codes' => $codes])->save();
        ActivityLog::record('admin.2fa_codes_regenerated', 'Made new recovery codes');

        return redirect()->route('admin.security')->with('new_recovery_codes', $codes)->with('success', 'New recovery codes created. The old ones no longer work.');
    }

    public function disable(Request $request)
    {
        $user = $request->user();
        if ($error = $this->checkPasswordAndCode($request)) {
            return back()->withErrors($error);
        }

        $user->forceFill(['two_factor_secret' => null, 'two_factor_recovery_codes' => null, 'two_factor_confirmed_at' => null])->save();
        $request->session()->forget('two_factor_passed_for');
        ActivityLog::record('admin.2fa_disabled', 'Turned off two-step verification');

        return redirect()->route('admin.security')->with('success', 'Two-step verification is off.');
    }

    /** Sensitive changes need BOTH the password and a current code. */
    private function checkPasswordAndCode(Request $request): ?array
    {
        $request->validate(['password' => 'required|string', 'code' => 'required|string|max:12']);
        $user = $request->user();

        if (! Hash::check($request->password, $user->password)) {
            return ['password' => 'Your password is not correct.'];
        }
        if (! $user->two_factor_secret || ! Totp::verify($user->two_factor_secret, $request->code)) {
            return ['code' => 'That code is not correct.'];
        }

        return null;
    }

    /** 8 one-time codes like "k3f9a-7d2xq". */
    private function makeRecoveryCodes(): array
    {
        return collect(range(1, 8))
            ->map(fn () => Str::lower(Str::random(5).'-'.Str::random(5)))
            ->all();
    }
}
