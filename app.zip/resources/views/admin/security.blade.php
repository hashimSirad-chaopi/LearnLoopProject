<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Security</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>

<div class="admin-container">

    @include('partials.admin-sidebar')

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Security</h1>
                <p>Protect the admin account with a second step when you sign in.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    @include('partials.flash')

                    <div class="sec-grid">

                        {{-- ===== Recovery codes, shown once ===== --}}
                        @if($newCodes)
                            <div class="ll-card">
                                <h3>Save your recovery codes</h3>
                                <div class="sec-warn">
                                    These are shown <strong>only once</strong>. Keep them somewhere safe (a password manager or printed). Each code works one time if you lose your phone.
                                </div>
                                <div class="sec-codes">
                                    @foreach($newCodes as $code)<code>{{ $code }}</code>@endforeach
                                </div>
                            </div>
                        @endif

                        {{-- ===== Status ===== --}}
                        <div class="ll-card">
                            <div class="ll-row between">
                                <h3>Two-step verification</h3>
                                <span class="ll-badge {{ $enabled ? 'completed' : 'pending' }}">{{ $enabled ? 'On' : 'Off' }}</span>
                            </div>

                            @if(! $enabled && ! $pending)
                                <p>Right now anyone who learns your password can sign in. With two-step verification you also need the 6-digit code from an authenticator app on your phone (Google Authenticator, Microsoft Authenticator, Authy, 1Password...).</p>
                                <form method="POST" action="{{ route('admin.security.enable') }}">
                                    @csrf
                                    <button type="submit" class="settings-save-btn">Set up two-step verification</button>
                                </form>

                            @elseif($pending)
                                <p><strong>Step 1.</strong> In your authenticator app choose “Add account”, then “Enter a setup key”. Use this key (spaces do not matter):</p>
                                <code class="sec-secret">{{ $secret }}</code>
                                <p class="ll-muted">Account name: {{ auth()->user()->email }} &middot; Type: time-based &middot; On a phone you can also <a href="{{ $otpauth }}">tap here to open your authenticator app</a>.</p>

                                <p><strong>Step 2.</strong> Type the 6-digit code the app now shows to finish:</p>
                                <form method="POST" action="{{ route('admin.security.confirm') }}" class="sec-form">
                                    @csrf
                                    <input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" placeholder="123456" maxlength="7" required>
                                    <button type="submit" class="settings-save-btn">Turn on</button>
                                </form>
                                @error('code')<p class="sec-error">{{ $message }}</p>@enderror

                            @else
                                <div class="sec-ok">
                                    You are asked for a code each time you sign in. You have <strong>{{ $recoveryLeft }}</strong> unused recovery {{ \Illuminate\Support\Str::plural('code', $recoveryLeft) }}.
                                </div>
                            @endif
                        </div>

                        {{-- ===== Manage (only when on) ===== --}}
                        @if($enabled)
                            <div class="ll-card">
                                <h3>Make new recovery codes</h3>
                                <p class="ll-muted">The old codes stop working. Needs your password and a current code.</p>
                                <form method="POST" action="{{ route('admin.security.codes') }}" class="sec-form">
                                    @csrf
                                    <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                                    <input type="text" name="code" inputmode="numeric" placeholder="6-digit code" maxlength="7" required>
                                    <button type="submit" class="table-btn">Make new codes</button>
                                </form>
                            </div>

                            <div class="ll-card">
                                <h3>Turn off two-step verification</h3>
                                <p class="ll-muted">Not recommended. Needs your password and a current code.</p>
                                <form method="POST" action="{{ route('admin.security.disable') }}" class="sec-form" onsubmit="return confirm('Turn off two-step verification?');">
                                    @csrf
                                    <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                                    <input type="text" name="code" inputmode="numeric" placeholder="6-digit code" maxlength="7" required>
                                    <button type="submit" class="delete-btn">Turn off</button>
                                </form>
                                @error('password')<p class="sec-error">{{ $message }}</p>@enderror
                                @error('code')<p class="sec-error">{{ $message }}</p>@enderror
                            </div>
                        @endif

                        {{-- ===== What is protected ===== --}}
                        <div class="ll-card">
                            <h3>Other protection already in place</h3>
                            <ul class="ll-muted" style="padding-left:18px; line-height:1.8;">
                                <li>Admin login locks for a minute after 5 wrong tries.</li>
                                <li>Only active admin accounts can sign in to this panel.</li>
                                <li>App login and sign-up are rate limited.</li>
                                <li>Every admin action, sign-in and failed sign-in is recorded in <a href="{{ route('admin.activity') }}">Activity</a>.</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
