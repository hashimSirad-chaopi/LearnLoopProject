<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('reports', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->foreignId('reported_by')->nullable()->constrained('users')->nullOnDelete();
        $table->foreignId('reported_user_id')->nullable()->constrained('users')->nullOnDelete();
        $table->foreignId('listing_id')->nullable()->constrained('listings')->nullOnDelete();
        $table->text('reason');
        $table->enum('status', ['pending', 'resolved', 'dismissed'])->default('pending');
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('reports');
}
};
