<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Verify sign-in &middot; <?php echo e(config('app.name', 'LearnLoop')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>
<body>

    <main id="container">

        <div class="auth-brand">LEARN LOOP</div>

        <div class="auth-header">
            <span class="auth-label">Admin Panel</span>
            <h1>Check your email</h1>
            <p>We sent a 6-digit code to <strong><?php echo e($maskedEmail); ?></strong>. It works for <?php echo e(\App\Support\EmailOtp::TTL_MINUTES); ?> minutes.</p>
        </div>

        <?php if(session('status')): ?>
            <p class="auth-status" role="status"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if($sendError): ?>
            <p class="auth-error" role="alert"><?php echo e($sendError); ?></p>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.verify.check')); ?>" class="auth-form">
            <?php echo csrf_field(); ?>

            <div class="auth-field">
                <label for="code">Code</label>
                <input
                    id="code"
                    type="text"
                    name="code"
                    inputmode="numeric"
                    autocomplete="one-time-code"
                    maxlength="6"
                    placeholder="123456"
                    class="<?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>"
                    required
                    autofocus
                >
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="auth-error" role="alert"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <label style="display:flex; gap:8px; align-items:center; font-size:13.5px; margin:0 0 14px;">
                <input type="checkbox" name="trust" value="1" style="width:auto; margin:0;">
                Trust this browser for <?php echo e(\App\Support\AdminDevices::DAYS); ?> days (do not ask again here)
            </label>

            <button type="submit" class="auth-submit">Verify</button>
        </form>

        <form method="POST" action="<?php echo e(route('admin.verify.resend')); ?>" style="margin-top:14px; text-align:center;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="forgot-link" style="background:none; border:0; cursor:pointer;">
                Did not get it? Send a new code<?php echo e($wait > 0 ? " (wait {$wait}s)" : ''); ?>

            </button>
        </form>

        <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin-top:8px; text-align:center;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="forgot-link" style="background:none; border:0; cursor:pointer;">Sign out instead</button>
        </form>

    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/auth/admin-verify.blade.php ENDPATH**/ ?>