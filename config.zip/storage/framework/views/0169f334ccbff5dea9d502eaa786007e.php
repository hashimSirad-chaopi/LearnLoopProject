<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Activity Log</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Activity Log</h1>
                <p>A record of every administrative action.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="users-scroll-area">
                <div class="users-table-container">
                    <div class="ll-toolbar">
                        <form method="GET" action="<?php echo e(route('admin.activity')); ?>" class="ll-search">
                            <select name="type" aria-label="Filter by type" onchange="this.form.submit()">
                                <option value="">All activity</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e($type === $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search the log" aria-label="Search the activity log">
                            <button type="submit" class="table-btn">Search</button>
                            <?php if($search !== '' || $type !== ''): ?>
                                <a href="<?php echo e(route('admin.activity')); ?>" class="table-btn ll-link">Clear</a>
                            <?php endif; ?>
                        </form>
                    </div>
                    <span class="ll-muted">
                        <?php echo e(number_format($logs->total())); ?> <?php echo e(\Illuminate\Support\Str::plural('entry', $logs->total())); ?>

                        <?php if($type !== ''): ?> &middot; <?php echo e($types[$type]); ?> only <?php endif; ?>
                        <?php if($search !== ''): ?> &middot; matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                    </span>

                    <table class="users-table activity-table">
                        <thead>
                            <tr>
                                <th>When</th>
                                <th>Admin</th>
                                <th>Action</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($log->created_at->format('M j, g:i A')); ?></td>
                                    <td><?php echo e($log->admin->name ?? 'Deleted admin'); ?></td>
                                    <td><?php echo e($log->action); ?></td>
                                    <td><?php echo e($log->description); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4"><?php echo e($search !== '' || $type !== '' ? 'No activity matches these filters.' : 'No activity recorded yet.'); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php echo e($logs->links('vendor.pagination.admin')); ?>

        </section>
    </main>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/activity.blade.php ENDPATH**/ ?>