<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Categories</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Categories</h1>
                <p>Group skills into categories. Listings use the category of their skill.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.catalog-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-toolbar">
                        <form method="GET" action="<?php echo e(route('admin.categories')); ?>" class="ll-search">
                            <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Search categories or skills" aria-label="Search categories or skills">
                            <button type="submit" class="table-btn">Search</button>
                            <?php if($search !== ''): ?><a href="<?php echo e(route('admin.categories')); ?>" class="table-btn ll-link">Clear</a><?php endif; ?>
                        </form>

                        <form method="POST" action="<?php echo e(route('admin.categories.store')); ?>" class="ll-search">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="New category name" aria-label="New category name" required>
                            <button type="submit" class="settings-save-btn">+ Add category</button>
                        </form>
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="ll-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php if($uncategorized > 0): ?>
                        <div class="ll-note">
                            <strong><?php echo e($uncategorized); ?> <?php echo e(\Illuminate\Support\Str::plural('skill', $uncategorized)); ?></strong> <?php echo e($uncategorized === 1 ? 'has' : 'have'); ?> no category.
                            <a href="<?php echo e(route('admin.skills', ['category' => 'none'])); ?>">Review them</a> and pick a category so they appear in the right place.
                        </div>
                    <?php endif; ?>

                    <span class="ll-muted"><?php echo e($categories->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('category', $categories->count())); ?><?php echo e($search !== '' ? ' match "'.$search.'"' : ''); ?></span>

                    <div class="ll-grid wide">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php ($lessons = (int) ($lessonCounts[$category->id] ?? 0)); ?>
                            <article class="ll-card ll-cat">
                                <h3><?php echo e($category->name); ?></h3>

                                <div class="ll-counts">
                                    <span><strong><?php echo e($category->skills_count); ?></strong> <?php echo e(\Illuminate\Support\Str::plural('skill', $category->skills_count)); ?></span>
                                    <span><strong><?php echo e($lessons); ?></strong> <?php echo e(\Illuminate\Support\Str::plural('lesson', $lessons)); ?></span>
                                    <span><strong><?php echo e($category->listings_count); ?></strong> <?php echo e(\Illuminate\Support\Str::plural('listing', $category->listings_count)); ?></span>
                                </div>

                                <div class="ll-chips">
                                    <?php $__empty_2 = true; $__currentLoopData = $category->skills->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <a class="ll-chip <?php echo e($skill->status === 'inactive' ? 'muted' : ''); ?>" href="<?php echo e(route('admin.skills.show', $skill)); ?>" title="<?php echo e($skill->status === 'inactive' ? 'Inactive' : 'Open skill'); ?>"><?php echo e($skill->icon ?: '📘'); ?> <?php echo e($skill->title); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="ll-muted">No skills yet.</span>
                                    <?php endif; ?>
                                    <?php if($category->skills->count() > 6): ?>
                                        <a class="ll-chip more" href="<?php echo e(route('admin.skills', ['category' => $category->id])); ?>">+<?php echo e($category->skills->count() - 6); ?> more</a>
                                    <?php endif; ?>
                                </div>

                                <div class="ll-actions">
                                    <a href="<?php echo e(route('admin.skills', ['category' => $category->id])); ?>" class="table-btn ll-link">Open skills</a>
                                    <a href="<?php echo e(route('admin.skills.create', ['category' => $category->id])); ?>" class="settings-save-btn ll-link">+ Add skill</a>
                                </div>

                                <details class="ll-more">
                                    <summary>Rename or delete</summary>
                                    <form method="POST" action="<?php echo e(route('admin.categories.update', $category->id)); ?>" class="ll-search">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <input type="text" name="name" value="<?php echo e($category->name); ?>" aria-label="Category name" required>
                                        <button type="submit" class="table-btn">Save</button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.categories.delete', $category->id)); ?>"
                                          onsubmit="return confirm('Delete <?php echo e(addslashes($category->name)); ?>?<?php echo e($category->skills_count > 0 ? ' Its '.$category->skills_count.' skills will stay, but have no category.' : ''); ?>');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="delete-btn">Delete category</button>
                                    </form>
                                    <?php if($category->skills_count > 0): ?>
                                        <p class="ll-muted">Deleting keeps the skills and their lessons. They just lose this category.</p>
                                    <?php endif; ?>
                                </details>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="ll-card">
                                <h3><?php echo e($search !== '' ? 'No categories match' : 'No categories yet'); ?></h3>
                                <p><?php echo e($search !== '' ? 'Try a different search.' : 'Add your first category above, or run the sample seeder: php artisan db:seed --class=CategorySeeder'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/categories.blade.php ENDPATH**/ ?>