<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - View User</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .ud-head { padding: 0; overflow: hidden; }
        .ud-banner { height: 120px; background: linear-gradient(120deg, #16231C, #2B3C31); background-size: cover; background-position: center; }
        .ud-id { display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-start; padding: 0 20px; }
        .ud-avatar { position: relative; margin-top: -42px; width: 84px; height: 84px; border-radius: 18px; overflow: hidden; border: 4px solid #FBFDF9; background: #B7FF72; flex-shrink: 0; }
        .ud-avatar img, .ud-initials { position: absolute; inset: 0; width: 100%; height: 100%; }
        .ud-avatar img { object-fit: cover; }
        .ud-initials { display: flex; align-items: center; justify-content: center; font-size: 30px; font-weight: 800; color: #16231C; }
        .ud-id-text { flex: 1; min-width: 200px; padding-top: 14px; }
        .ud-id-text h2 { margin: 0; font-size: 22px; overflow-wrap: anywhere; }
        .ud-id-text p { margin: 2px 0 6px; }
        .ud-badges { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .ud-actions { display: flex; gap: 8px; align-items: center; padding-top: 14px; }
        .ud-head > p, .ud-head > .ud-alert { margin-left: 20px; margin-right: 20px; }
        .ud-head > .ud-bio { margin-top: 16px; }
        .ud-head > .ll-muted { margin-top: 8px; }
        .ud-head > p:last-child { margin-bottom: 16px; }
        .ud-bio { margin-top: 14px; white-space: pre-line; overflow-wrap: anywhere; }
        .ud-alert { margin-top: 14px; padding: 10px 14px; border-radius: 10px; background: #F9E9E7; border: 1px solid #E3B8B4; color: #7A2F2A; font-size: 13px; line-height: 1.5; }
        .ud-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; }
        .ud-stats > div { background: var(--ll-surface, #FBFDF9); border: 1px solid var(--ll-border, #CAD5CB); border-radius: 12px; padding: 12px 14px; }
        .ud-stats span { display: block; color: var(--ll-muted, #69766E); font-size: 11px; font-weight: 800; letter-spacing: .6px; text-transform: uppercase; }
        .ud-stats strong { display: block; font-size: 22px; color: var(--ll-forest, #16231C); }
        .ud-stats small { color: var(--ll-muted, #69766E); font-size: 12px; }
        .ud-stats .ud-warn { background: #FFF4DD; border-color: #E4C77A; }
        .ud-cols { display: grid; grid-template-columns: minmax(0, 1fr) 340px; gap: 16px; align-items: start; }
        .ud-main, .ud-side { display: flex; flex-direction: column; gap: 16px; min-width: 0; }
        .lp-skill { padding: 14px 0; border-top: 1px solid var(--ll-border, #CAD5CB); }
        .lp-skill:first-of-type { border-top: 0; }
        .lp-head { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .lp-total { display: flex; align-items: center; gap: 12px; margin-top: 8px; }
        .lp-total .lp-track { flex: 1; }
        .lp-track { height: 8px; border-radius: 999px; background: #EDF3EB; overflow: hidden; }
        .lp-track span { display: block; height: 100%; border-radius: 999px; background: #55783B; }
        .lp-now { margin: 8px 0 10px; font-size: 13px; }
        .lp-levels { display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 10px; }
        .lp-level .lp-track { height: 6px; }
        .lp-level.done .lp-track span { background: #8FD64C; }
        .lp-level.locked { opacity: .55; }
        .lp-level-text { display: flex; justify-content: space-between; gap: 6px; margin-top: 4px; font-size: 12px; }
        .lp-level.now .lp-level-text strong { color: #16231C; }
        .lp-level-text span { color: var(--ll-muted, #69766E); }
        .ud-item { padding: 10px 0; border-top: 1px solid var(--ll-border, #CAD5CB); }
        .ud-item:first-of-type { border-top: 0; padding-top: 4px; }
        .ud-item p { margin: 4px 0 0; }
        @media (max-width: 1000px) { .ud-cols { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="admin-container">

      <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>User Details</h1>
                <p>Viewing account information.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php
                        $isSelf = $user->id === auth()->id();
                        $locked = $isSelf || $user->role === 'admin';
                    ?>

                    
                    <div class="ll-card ud-head">
                        <div class="ud-banner" <?php if($user->banner_url): ?> style="background-image:url('<?php echo e($user->banner_url); ?>')" <?php endif; ?>></div>
                        <div class="ud-id">
                            <div class="ud-avatar">
                                <span class="ud-initials"><?php echo e(mb_strtoupper(mb_substr(trim($user->name), 0, 1))); ?></span>
                                <?php if($user->avatar_url): ?><img src="<?php echo e($user->avatar_url); ?>" alt="<?php echo e($user->name); ?>" onerror="this.remove()"><?php endif; ?>
                            </div>
                            <div class="ud-id-text">
                                <h2><?php echo e($user->name); ?> <?php if($isSelf): ?><span class="ll-muted">(you)</span><?php endif; ?></h2>
                                <p class="ll-muted"><?php echo e($user->email); ?></p>
                                <div class="ud-badges">
                                    <span class="ll-badge <?php echo e($user->role === 'admin' ? 'trusted' : ''); ?>"><?php echo e(ucfirst($user->role)); ?></span>
                                    <span class="ll-badge <?php echo e(['active' => 'active', 'offline' => 'inactive', 'suspended' => 'rejected'][$user->presence]); ?>"><?php echo e(ucfirst($user->presence)); ?></span>
                                    <?php if($user->presence === 'offline'): ?>
                                        <span class="ll-muted"><?php echo e($user->last_seen_at ? 'last seen '.$user->last_seen_at->diffForHumans() : 'not seen yet'); ?></span>
                                    <?php elseif($user->presence === 'active'): ?>
                                        <span class="ll-muted">online now</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="ud-actions">
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="table-btn" style="text-decoration:none;">Edit</a>
                                <?php if (! ($locked)): ?>
                                    <?php if($user->status === 'suspended'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.users.activate', $user->id)); ?>" onsubmit="return confirm('Reactivate <?php echo e($user->name); ?>?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="settings-save-btn">Reactivate</button>
                                        </form>
                                    <?php else: ?>
                                        <button type="button" class="delete-btn"
                                                data-suspend-open data-suspend-url="<?php echo e(route('admin.users.suspend', $user->id)); ?>" data-suspend-name="<?php echo e($user->name); ?>">Suspend</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if($user->status === 'suspended'): ?>
                            <div class="ud-alert">
                                <strong>Suspended</strong>
                                <?php echo e($user->suspended_until ? 'until '.$user->suspended_until->format('M j, Y g:i A') : 'until you reactivate the account'); ?>

                                <?php if($why = \App\Support\Suspension::describe($user->suspension_reason, $user->suspension_note)): ?>
                                    <br>Reason: <?php echo e($why); ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if($user->bio): ?><p class="ud-bio"><?php echo e($user->bio); ?></p><?php endif; ?>
                        <p class="ll-muted">
                            Member since <?php echo e($user->created_at->format('F j, Y')); ?> (<?php echo e($user->created_at->diffForHumans()); ?>)
                            <?php if($user->availability): ?> &middot; Availability: <?php echo e($user->availability); ?> <?php endif; ?>
                        </p>
                    </div>

                    
                    <div class="ud-stats">
                        <div><span>Rating</span><strong><?php echo e($ratingCount ? $ratingAverage . '★' : '—'); ?></strong><small><?php echo e($ratingCount); ?> <?php echo e(\Illuminate\Support\Str::plural('rating', $ratingCount)); ?></small></div>
                        <div><span>Exchanges</span><strong><?php echo e($stats['exchanges']); ?></strong><small><?php echo e($completedExchanges); ?> completed</small></div>
                        <div><span>Listings</span><strong><?php echo e($stats['listings']); ?></strong></div>
                        <div><span>Comments</span><strong><?php echo e($stats['comments']); ?></strong>
                            <?php if($stats['comments'] > 0): ?><small><a class="cell-link" href="<?php echo e(route('admin.comments', ['search' => $user->email])); ?>">view all</a></small><?php endif; ?>
                        </div>
                        <div><span>Lessons written</span><strong><?php echo e($lessonsWritten); ?></strong></div>
                        <div class="<?php echo e($stats['reports_upheld'] > 0 ? 'ud-warn' : ''); ?>"><span>Reports against</span><strong><?php echo e($stats['reports_against']); ?></strong>
                            <small><?php echo e($stats['reports_upheld']); ?> upheld &middot; <?php echo e($stats['warnings']); ?> <?php echo e(\Illuminate\Support\Str::plural('warning', $stats['warnings'])); ?></small>
                        </div>
                    </div>

                    <div class="ud-cols">
                    <div class="ud-main">

                    <div class="ll-card">
                        <h3>Skills they can teach</h3>
                        <p class="ll-muted">Levels are earned, not typed in: a member can teach a skill up to the level whose lessons they passed (Professional needs approved proof + the hard quiz).</p>
                        <?php $__empty_1 = true; $__currentLoopData = $skillsOffered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="ll-lesson">
                                <strong><?php echo e($row->skill?->icon); ?> <?php echo e($row->skill?->title ?? 'Removed skill'); ?></strong>
                                <?php if($row->level): ?><span class="ll-badge <?php echo e($row->level); ?>"><?php echo e(ucfirst($row->level)); ?></span>
                                <?php else: ?><span class="ll-badge pending">Not earned yet</span><?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="ll-muted">No skills to teach yet. They can still post learner-only listings.</p>
                        <?php endif; ?>
                    </div>

                    <div class="ll-card">
                        <h3>Learning progress</h3>
                        <p class="ll-muted">The skills they picked or started, with their progress in each level. A level opens once the one before it is passed.</p>
                        <?php $__empty_1 = true; $__currentLoopData = $learning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $wants = in_array($row['skill_id'], $wantedIds);
                                $teaches = in_array($row['skill_id'], $offeredIds);
                                $current = $row['next_level'];
                            ?>
                            <div class="lp-skill">
                                <div class="lp-head">
                                    <strong><?php echo e($row['title']); ?></strong>
                                    <?php if($wants): ?><span class="ll-badge">Wants to learn</span><?php endif; ?>
                                    <?php if($teaches): ?><span class="ll-badge trusted">Teaches</span><?php endif; ?>
                                    <?php if($row['earned_level']): ?><span class="ll-badge <?php echo e($row['earned_level']); ?>">Can teach: <?php echo e(ucfirst($row['earned_level'])); ?></span><?php else: ?><span class="ll-badge pending">No level yet</span><?php endif; ?>
                                    <?php if($row['professional'] === 'in_review'): ?><span class="ll-badge pending">Professional proof waiting</span><?php endif; ?>
                                </div>

                                <div class="lp-total">
                                    <div class="lp-track"><span style="width: <?php echo e($row['percent']); ?>%"></span></div>
                                    <span class="ll-muted"><?php echo e($row['lessons_passed']); ?>/<?php echo e($row['lessons_total']); ?> lessons &middot; <?php echo e($row['percent']); ?>%</span>
                                </div>

                                <p class="lp-now">
                                    <?php if($row['lessons_passed'] === 0 && $current): ?>
                                        Not started yet. First level: <strong><?php echo e(ucfirst($current)); ?></strong>
                                    <?php elseif($current): ?>
                                        Working on <strong><?php echo e(ucfirst($current)); ?></strong>
                                    <?php else: ?>
                                        <strong>All levels complete</strong>
                                    <?php endif; ?>
                                </p>

                                <div class="lp-levels">
                                    <?php $__currentLoopData = collect($row['levels'])->where('total', '>', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="lp-level <?php echo e($level['complete'] ? 'done' : ($level['name'] === $current ? 'now' : '')); ?> <?php echo e($level['unlocked'] || $level['complete'] ? '' : 'locked'); ?>">
                                            <div class="lp-track"><span style="width: <?php echo e($level['percent']); ?>%"></span></div>
                                            <div class="lp-level-text">
                                                <strong><?php echo e(ucfirst($level['name'])); ?></strong>
                                                <span><?php echo e($level['complete'] ? '✓ ' : (($level['unlocked'] || $level['complete']) ? '' : '🔒 ')); ?><?php echo e($level['passed']); ?>/<?php echo e($level['total']); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="ll-muted">They have not picked or started a skill with lessons yet.</p>
                        <?php endif; ?>
                    </div>

                    <div class="ll-card">
                        <h3>Skills they want to learn</h3>
                        <p style="display:flex;flex-wrap:wrap;gap:8px;">
                            <?php $__empty_1 = true; $__currentLoopData = $skillsWanted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <span class="ll-badge"><?php echo e($row->skill?->icon); ?> <?php echo e($row->skill?->title ?? 'Removed skill'); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <span class="ll-muted">None listed.</span>
                            <?php endif; ?>
                        </p>
                    </div>

                    <?php if($authorTrust->isNotEmpty()): ?>
                        <div class="ll-card">
                            <h3>Lesson author status</h3>
                            <table class="ll-table">
                                <thead><tr><th>Skill</th><th>Approved lessons</th><th>Ratings</th><th>Trusted</th></tr></thead>
                                <tbody>
                                <?php $__currentLoopData = $authorTrust; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row['skill']->title); ?></td>
                                        <td><?php echo e($row['approved']); ?> / <?php echo e(\App\Support\AuthorTrust::APPROVALS_NEEDED); ?></td>
                                        <td><?php echo e($row['rating_count']); ?><?php echo e($row['rating_count'] ? ' · ' . $row['average'] . '★' : ''); ?></td>
                                        <td><span class="ll-badge <?php echo e($row['is_trusted'] ? 'trusted' : ''); ?>"><?php echo e($row['is_trusted'] ? 'Trusted' : 'Not yet'); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    </div>

                    <div class="ud-side">

                        <div class="ll-card">
                            <h3>Reports against them</h3>
                            <?php $__empty_1 = true; $__currentLoopData = $recentReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ud-item">
                                    <strong><?php echo e(\Illuminate\Support\Str::limit($report->title, 60)); ?></strong>
                                    <span class="ll-badge <?php echo e(['pending' => 'pending', 'resolved' => 'rejected', 'dismissed' => 'inactive'][$report->status] ?? ''); ?>"><?php echo e(ucfirst($report->status)); ?></span>
                                    <p class="ll-muted">By <?php echo e($report->reporter?->name ?? 'a deleted member'); ?> &middot; <?php echo e($report->created_at->diffForHumans()); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">No one has reported this member.</p>
                            <?php endif; ?>
                            <?php if($stats['reports_against'] > 0): ?>
                                <a class="cell-link" href="<?php echo e(route('admin.reports', ['search' => $user->name])); ?>">Open in Reports &rarr;</a>
                            <?php endif; ?>
                            <?php if($stats['reports_filed'] > 0): ?>
                                <p class="ll-muted" style="margin-top:8px;">They have filed <?php echo e($stats['reports_filed']); ?> <?php echo e(\Illuminate\Support\Str::plural('report', $stats['reports_filed'])); ?> themselves.</p>
                            <?php endif; ?>
                        </div>

                        <div class="ll-card">
                            <h3>Suspension history</h3>
                            <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ud-item">
                                    <strong><?php echo e($entry->action === 'user.suspended' ? 'Suspended' : 'Reactivated'); ?></strong>
                                    <span class="ll-muted"><?php echo e($entry->created_at->format('M j, Y g:i A')); ?><?php if($entry->admin): ?> &middot; by <?php echo e($entry->admin->name); ?><?php endif; ?></span>
                                    <p class="ll-muted"><?php echo e(\Illuminate\Support\Str::limit($entry->description, 140)); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">Never suspended.</p>
                            <?php endif; ?>
                        </div>

                        <div class="ll-card">
                            <h3>Latest comments</h3>
                            <?php $__empty_1 = true; $__currentLoopData = $recentComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ud-item">
                                    <p style="white-space:pre-line;overflow-wrap:anywhere;"><?php echo e(\Illuminate\Support\Str::limit($comment->body, 140)); ?></p>
                                    <p class="ll-muted">On <?php echo e($comment->listing ? '“'.\Illuminate\Support\Str::limit($comment->listing->title, 40).'”' : 'a deleted listing'); ?> &middot; <?php echo e($comment->created_at->diffForHumans()); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">No comments yet.</p>
                            <?php endif; ?>
                        </div>

                        <div class="ll-card">
                            <h3>Latest listings</h3>
                            <?php $__empty_1 = true; $__currentLoopData = $recentListings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ud-item">
                                    <a class="cell-link" href="<?php echo e(route('admin.listings.edit', $listing)); ?>"><strong><?php echo e(\Illuminate\Support\Str::limit($listing->title, 50)); ?></strong></a>
                                    <span class="ll-badge <?php echo e($listing->status === 'active' ? 'active' : 'inactive'); ?>"><?php echo e(ucfirst($listing->status)); ?></span>
                                    <p class="ll-muted"><?php echo e($listing->created_at->diffForHumans()); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">No listings yet.</p>
                            <?php endif; ?>
                        </div>

                    </div>
                    </div>

                    <div class="settings-actions">
                        <a href="<?php echo e(route('admin.users')); ?>" class="table-btn">Back</a>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<?php echo $__env->make('partials.suspend-dialog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/users-show.blade.php ENDPATH**/ ?>