<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Exchange Monitoring</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

       <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Exchange Monitoring</h1>
                <p>Track all ongoing and completed skill exchanges between users.</p>
            </div>
        </header>

        <section class="users-page">

            <div class="users-toolbar">
                <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <div class="dashboard-heading">

                    <div>

                        <span class="section-label">
                            EXCHANGES
                        </span>

                        <h2>
                            All Exchanges
                        </h2>

                        <p>
                            View and manage all recorded skill exchanges.
                        </p>

                    </div>

                </div>

                <div class="ll-tabs" style="margin-bottom:12px;">
                    <a class="ll-tab <?php echo e($statusFilter === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges')); ?>">All (<?php echo e($counts->sum()); ?>)</a>
                    <a class="ll-tab <?php echo e($statusFilter === 'disputed' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges', ['status' => 'disputed'])); ?>">Disputed (<?php echo e($counts['disputed'] ?? 0); ?>)</a>
                    <a class="ll-tab <?php echo e($statusFilter === 'pending' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges', ['status' => 'pending'])); ?>">Pending (<?php echo e($counts['pending'] ?? 0); ?>)</a>
                    <a class="ll-tab <?php echo e($statusFilter === 'ongoing' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges', ['status' => 'ongoing'])); ?>">Ongoing (<?php echo e($counts['ongoing'] ?? 0); ?>)</a>
                    <a class="ll-tab <?php echo e($statusFilter === 'completed' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges', ['status' => 'completed'])); ?>">Completed (<?php echo e($counts['completed'] ?? 0); ?>)</a>
                    <a class="ll-tab <?php echo e($statusFilter === 'cancelled' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exchanges', ['status' => 'cancelled'])); ?>">Cancelled (<?php echo e($counts['cancelled'] ?? 0); ?>)</a>
                </div>

                <div class="user-tools">

                    <a href="<?php echo e(route('admin.exchanges.create')); ?>" class="settings-save-btn" style="text-decoration:none;">+ Add Exchange</a>

                </div>

            </div>

           <div class="users-scroll-area">

    <div class="users-table-container">

        <table class="users-table exchanges-table">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Provider</th>
                    <th>Learner</th>
                    <th>Skills (provider teaches ↔ learner teaches)</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $exchanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#EX-<?php echo e(str_pad($exchange->id, 3, '0', STR_PAD_LEFT)); ?></td>
                        <td><?php echo e($exchange->provider->name ?? 'N/A'); ?></td>
                        <td><?php echo e($exchange->learner->name ?? 'N/A'); ?></td>
                        <td>
                            <?php echo e($exchange->skillPair()); ?>

                            <?php if($exchange->status === 'disputed' && $exchange->dispute_reason): ?>
                                <div class="ll-muted"><?php echo e(\Illuminate\Support\Str::limit($exchange->dispute_reason, 70)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="ll-badge <?php echo e($exchange->status); ?>"><?php echo e(ucfirst($exchange->status)); ?></span>
                            <?php if($exchange->isLearnerOnly()): ?><span class="ll-badge learner-only">Learner only</span><?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.exchanges.show', $exchange->id)); ?>" class="table-btn" style="text-decoration:none;">View</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6">No exchanges found.</td></tr>
                <?php endif; ?>
            </tbody>

        </table>

    </div>

    <?php echo e($exchanges->links('vendor.pagination.admin')); ?>


</div>

        </section>
    </main>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/exchanges.blade.php ENDPATH**/ ?>