
<?php
    $letters = $letters ?? 1;
    $initials = mb_strtoupper(mb_substr(trim($user->name ?? '?'), 0, $letters));
?>
<span class="<?php echo e($class ?? 'user-avatar'); ?> has-avatar">
    <span class="avatar-initials"><?php echo e($initials); ?></span>
    <?php if($user->avatar_url): ?>
        <img class="avatar-img" src="<?php echo e($user->avatar_url); ?>" alt="<?php echo e($user->name); ?>" loading="lazy" onerror="this.remove()">
    <?php endif; ?>
</span>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/partials/avatar.blade.php ENDPATH**/ ?>