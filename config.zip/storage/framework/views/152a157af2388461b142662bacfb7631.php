<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Admin Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .dash-trend { margin: 2px 0 10px; font-size: 12.5px; color: var(--ll-muted, #69766E); }
        .dash-down { color: #B14D48; font-weight: 800; }
        .dash-susp { font-style: normal; font-size: 10.5px; font-weight: 800; color: #B14D48; background: #F9E9E7; border-radius: 8px; padding: 1px 6px; margin-left: 4px; }
        .activity-indicator.ai-bad { background: #B14D48; box-shadow: 0 0 0 4px rgba(177, 77, 72, .18); }
        .activity-indicator.ai-info { background: #69766E; box-shadow: 0 0 0 4px rgba(105, 118, 110, .16); }
    </style>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>

        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Dashboard</h1>
                <p><?php echo e(now()->format('l, F j')); ?> &middot; Welcome back to LearnLoop.</p>
            </div>
        </header>

        <section class="dashboard-content">

            
            <div class="dash-tools">
                <div class="dash-range" aria-label="Date range">
                    <?php $__currentLoopData = [7 => 'Last 7 days', 30 => 'Last 30 days', 90 => 'Last 90 days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.home', ['range' => $d])); ?>" class="<?php echo e($stats['days'] === $d ? 'active' : ''); ?>"><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="dash-export" href="<?php echo e(route('admin.dashboard.export', ['range' => $stats['days']])); ?>">Export CSV</a>
            </div>

            
            <?php if($attentionTotal > 0): ?>
                <div class="dash-attention">
                    <div class="dash-attention-head">
                        <span class="section-label">NEEDS YOUR ATTENTION</span>
                        <h2><?php echo e($attentionTotal); ?> <?php echo e(\Illuminate\Support\Str::plural('item', $attentionTotal)); ?> waiting for you</h2>
                    </div>
                    <div class="dash-chips">
                        <?php $__currentLoopData = $attention; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item['count'] > 0): ?>
                                <a class="dash-chip" href="<?php echo e($item['url']); ?>" title="<?php echo e($item['hint']); ?>">
                                    <strong><?php echo e($item['count']); ?></strong>
                                    <span><?php echo e($item['label']); ?></span>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="dash-attention clear">
                    <div class="dash-attention-head">
                        <span class="section-label">ALL CAUGHT UP</span>
                        <h2>Nothing is waiting for you right now.</h2>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="dashboard-heading">
                <span class="section-label">OVERVIEW</span>
                <h2>System Overview</h2>
            </div>

            <div class="cards">
                <a class="card" href="<?php echo e(route('admin.users')); ?>">
                    <div class="card-top"><span class="card-label">MEMBERS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['totalMembers'])); ?></div>
                    <p class="card-description">
                        <?php if($stats['newMembersWeek'] > 0): ?>
                            <span class="dash-up">+<?php echo e($stats['newMembersWeek']); ?></span> in the last 7 days
                        <?php else: ?>
                            No new members this week
                        <?php endif; ?>
                    </p>
                </a>

                <a class="card" href="<?php echo e(route('admin.listings')); ?>">
                    <div class="card-top"><span class="card-label">ACTIVE LISTINGS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['activeListings'])); ?></div>
                    <p class="card-description">of <?php echo e(number_format($stats['totalListings'])); ?> total listings</p>
                </a>

                <a class="card" href="<?php echo e(route('admin.exchanges')); ?>">
                    <div class="card-top"><span class="card-label">ONGOING EXCHANGES</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['exchangeStatuses']['ongoing'])); ?></div>
                    <p class="card-description"><?php echo e(number_format($stats['exchangeStatuses']['completed'])); ?> completed so far</p>
                </a>

                <div class="card">
                    <div class="card-top"><span class="card-label">AVERAGE RATING</span></div>
                    <div class="card-value"><?php echo e($stats['avgRating'] ? $stats['avgRating'].' / 5' : '–'); ?></div>
                    <p class="card-description">
                        <?php echo e($stats['ratingsCount'] > 0 ? 'from '.number_format($stats['ratingsCount']).' '.\Illuminate\Support\Str::plural('rating', $stats['ratingsCount']) : 'No ratings yet'); ?>

                    </p>
                </div>

                <a class="card" href="<?php echo e(route('admin.skills')); ?>">
                    <div class="card-top"><span class="card-label">SKILLS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['skillCount'])); ?></div>
                    <p class="card-description">in <?php echo e(number_format($stats['categoryCount'])); ?> categories</p>
                </a>

                <a class="card" href="<?php echo e(route('admin.lessons')); ?>">
                    <div class="card-top"><span class="card-label">PUBLISHED LESSONS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['publishedLessons'])); ?></div>
                    <p class="card-description">live in the app</p>
                </a>

                <a class="card" href="<?php echo e(route('admin.reports')); ?>">
                    <div class="card-top"><span class="card-label">OPEN REPORTS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['pendingReports'])); ?></div>
                    <p class="card-description"><?php echo e($stats['pendingReports'] > 0 ? 'waiting for a decision' : 'nothing to review'); ?></p>
                </a>

                <a class="card" href="<?php echo e(route('admin.exchanges', ['status' => 'disputed'])); ?>">
                    <div class="card-top"><span class="card-label">DISPUTES</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['exchangeStatuses']['disputed'])); ?></div>
                    <p class="card-description"><?php echo e($stats['exchangeStatuses']['disputed'] > 0 ? 'exchanges a member reported' : 'no disputes'); ?></p>
                </a>

                <a class="card" href="<?php echo e(route('admin.users', ['status' => 'active'])); ?>">
                    <div class="card-top"><span class="card-label">ONLINE NOW</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['onlineNow'])); ?></div>
                    <p class="card-description">members using the app right now</p>
                </a>

                <a class="card" href="<?php echo e(route('admin.users', ['status' => 'suspended'])); ?>">
                    <div class="card-top"><span class="card-label">SUSPENDED</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['suspendedMembers'])); ?></div>
                    <p class="card-description"><?php echo e($stats['suspendedMembers'] > 0 ? 'members who cannot sign in' : 'nobody is suspended'); ?></p>
                </a>

                <a class="card" href="<?php echo e(route('admin.comments')); ?>">
                    <div class="card-top"><span class="card-label">COMMENTS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['commentsRange'])); ?></div>
                    <p class="card-description">in the last <?php echo e($stats['days']); ?> days &middot; <?php echo e(number_format($stats['commentsTotal'])); ?> in total</p>
                </a>

                <a class="card" href="<?php echo e(route('admin.listings')); ?>">
                    <div class="card-top"><span class="card-label">NEW LISTINGS</span></div>
                    <div class="card-value"><?php echo e(number_format($stats['newListingsRange'])); ?></div>
                    <p class="card-description">posted in the last <?php echo e($stats['days']); ?> days</p>
                </a>
            </div>

            
            <div class="dash-grid">

                <div class="dash-panel">
                    <div class="dash-panel-head">
                        <h3>New members</h3>
                        <span><?php echo e($stats['newMembersRange']); ?> in the last <?php echo e($stats['days']); ?> days</span>
                    </div>
                    <?php
                        $now = $stats['newMembersRange'];
                        $before = $stats['newMembersPrevious'];
                        $change = $before > 0 ? round(($now - $before) / $before * 100) : null;
                    ?>
                    <p class="dash-trend">
                        <?php if($change === null): ?>
                            <?php echo e($now > 0 ? 'No new members in the '.$stats['days'].' days before.' : 'No new members in either period.'); ?>

                        <?php elseif($change > 0): ?>
                            <span class="dash-up">&#9650; <?php echo e($change); ?>%</span> more than the <?php echo e($stats['days']); ?> days before (<?php echo e($before); ?>)
                        <?php elseif($change < 0): ?>
                            <span class="dash-down">&#9660; <?php echo e(abs($change)); ?>%</span> fewer than the <?php echo e($stats['days']); ?> days before (<?php echo e($before); ?>)
                        <?php else: ?>
                            Same as the <?php echo e($stats['days']); ?> days before (<?php echo e($before); ?>)
                        <?php endif; ?>
                    </p>
                    <?php ($maxSignup = max(1, max(array_column($stats['signups'], 'count')))); ?>
                    <div class="dash-bars">
                        <?php $__currentLoopData = $stats['signups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="dash-bar" title="<?php echo e($day['label']); ?>: <?php echo e($day['count']); ?> new">
                                <span class="dash-bar-count"><?php echo e($day['count'] ?: ''); ?></span>
                                <div class="dash-bar-fill <?php echo e($day['count'] === 0 ? 'empty' : ''); ?>" style="height: <?php echo e(max(4, round($day['count'] / $maxSignup * 100))); ?>%"></div>
                                <span class="dash-bar-day"><?php echo e($day['day']); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="dash-panel">
                    <div class="dash-panel-head">
                        <h3>Exchanges by status</h3>
                        <span><?php echo e(number_format($stats['totalExchanges'])); ?> total</span>
                    </div>
                    <?php if($stats['totalExchanges'] > 0): ?>
                        <div class="dash-stack">
                            <?php $__currentLoopData = $stats['exchangeStatuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($count > 0): ?>
                                    <div class="dash-seg st-<?php echo e($status); ?>" style="flex: <?php echo e($count); ?>" title="<?php echo e(ucfirst($status)); ?>: <?php echo e($count); ?>"></div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <ul class="dash-legend">
                            <?php $__currentLoopData = $stats['exchangeStatuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <span class="dash-dot st-<?php echo e($status); ?>"></span>
                                    <span class="dash-legend-name"><?php echo e(ucfirst($status)); ?></span>
                                    <strong><?php echo e(number_format($count)); ?></strong>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p class="dash-empty">No exchanges yet. They will show up here once members start trading skills.</p>
                    <?php endif; ?>
                </div>

            </div>

            
            <?php ($weeks = $stats['engagement']['weeks']); ?>
            <?php ($maxEng = max(1, max(array_merge([1], array_column($weeks, 'lessons'), array_column($weeks, 'exchanges'))))); ?>
            <div class="dash-panel" style="margin-bottom:22px;">
                <div class="dash-panel-head">
                    <h3>Weekly engagement</h3>
                    <span><?php echo e($stats['engagement']['lessonsTotal']); ?> lessons passed &middot; <?php echo e($stats['engagement']['exchangesTotal']); ?> exchanges completed</span>
                </div>
                <div class="dash-pairs">
                    <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="dash-pair" title="Week of <?php echo e($week['label']); ?>: <?php echo e($week['lessons']); ?> lessons passed, <?php echo e($week['exchanges']); ?> exchanges completed">
                            <div class="dash-pair-bars">
                                <div class="a <?php echo e($week['lessons'] === 0 ? 'zero' : ''); ?>" style="height: <?php echo e(max(3, round($week['lessons'] / $maxEng * 100))); ?>%"></div>
                                <div class="b <?php echo e($week['exchanges'] === 0 ? 'zero' : ''); ?>" style="height: <?php echo e(max(3, round($week['exchanges'] / $maxEng * 100))); ?>%"></div>
                            </div>
                            <span class="dash-pair-label"><?php echo e($week['label']); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="dash-key">
                    <span><i style="background:var(--ll-forest)"></i>Lessons passed</span>
                    <span><i style="background:#55A630"></i>Exchanges completed</span>
                    <span>each bar group = one week, starting on the date shown</span>
                </div>
            </div>

            
            <div class="dash-grid">

                <?php $__currentLoopData = [
                    ['title' => 'Most wanted skills', 'sub' => 'what members want to learn', 'rows' => $stats['topWanted']],
                    ['title' => 'Most offered skills', 'sub' => 'what members can teach', 'rows' => $stats['topOffered']],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="dash-panel">
                        <div class="dash-panel-head">
                            <h3><?php echo e($block['title']); ?></h3>
                            <span><?php echo e($block['sub']); ?></span>
                        </div>
                        <?php ($max = max(1, ...array_merge([1], array_column($block['rows'], 'count')))); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $block['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="dash-rank">
                                <div class="dash-rank-top"><span><?php echo e($row['name']); ?></span><strong><?php echo e($row['count']); ?></strong></div>
                                <div class="dash-rank-track"><div class="dash-rank-fill" style="width: <?php echo e(round($row['count'] / $max * 100)); ?>%"></div></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="dash-empty">Nothing yet. Members add skills on their profile.</p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            
            <div class="dash-grid">

                <div class="dash-panel">
                    <div class="dash-panel-head">
                        <h3>Top categories</h3>
                        <span>by number of listings</span>
                    </div>
                    <?php ($maxCat = max(1, ...array_merge([1], array_column($stats['topCategories'], 'count')))); ?>
                    <?php $__empty_1 = true; $__currentLoopData = $stats['topCategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dash-rank">
                            <div class="dash-rank-top"><span><?php echo e($row['name']); ?></span><strong><?php echo e($row['count']); ?></strong></div>
                            <div class="dash-rank-track"><div class="dash-rank-fill alt" style="width: <?php echo e(round($row['count'] / $maxCat * 100)); ?>%"></div></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="dash-empty">No listings with a category yet.</p>
                    <?php endif; ?>
                </div>

                <div class="dash-panel">
                    <div class="dash-panel-head">
                        <h3>Newest members</h3>
                        <a href="<?php echo e(route('admin.users')); ?>">View all</a>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $stats['recentMembers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="dash-member" href="<?php echo e(route('admin.users.show', $member)); ?>">
                            <?php echo $__env->make('partials.avatar', ['user' => $member, 'class' => 'dash-avatar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <span class="dash-member-text">
                                <strong><?php echo e($member->name); ?><?php if($member->status === 'suspended'): ?> <em class="dash-susp">Suspended</em><?php endif; ?></strong>
                                <small><?php echo e($member->email); ?></small>
                            </span>
                            <span class="dash-member-time"><?php echo e($member->created_at->diffForHumans(['short' => true])); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="dash-empty">No members yet.</p>
                    <?php endif; ?>
                </div>

            </div>

            
            <div class="recent-activity">
                <div class="activity-header">
                    <div>
                        <span class="section-label">ACTIVITY</span>
                        <h2>Recent Activity</h2>
                    </div>
                    <a class="dash-link" href="<?php echo e(route('admin.activity')); ?>">View all</a>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $stats['activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $kind = \Illuminate\Support\Str::contains($activity->action, ['deleted', 'suspended', 'rejected', 'removed']) ? 'bad'
                            : (\Illuminate\Support\Str::contains($activity->action, ['activated', 'approved', 'created', 'resolved', 'enabled']) ? 'good' : 'info');
                    ?>
                    <div class="activity-item">
                        <div class="activity-indicator ai-<?php echo e($kind); ?>"></div>
                        <div class="activity-text">
                            <strong><?php echo e($activity->description); ?></strong>
                            <p><?php echo e($activity->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="activity-item">
                        <div class="activity-indicator"></div>
                        <div class="activity-text">
                            <strong>No recent activity</strong>
                            <p>Admin actions such as approving a listing will be listed here.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        </section>
    </main>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/home.blade.php ENDPATH**/ ?>