<?php if($paginator->hasPages()): ?>
    <nav class="pager" role="navigation" aria-label="Pagination">

        <?php if($paginator->onFirstPage()): ?>
            <span class="pager-link is-disabled">&larr; Previous</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pager-link" rel="prev">&larr; Previous</a>
        <?php endif; ?>

        <span class="pager-status">
            Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?>

            <span class="cell-muted">(<?php echo e($paginator->total()); ?> total)</span>
        </span>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pager-link" rel="next">Next &rarr;</a>
        <?php else: ?>
            <span class="pager-link is-disabled">Next &rarr;</span>
        <?php endif; ?>

    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/vendor/pagination/admin.blade.php ENDPATH**/ ?>