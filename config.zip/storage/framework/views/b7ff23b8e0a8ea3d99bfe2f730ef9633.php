<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Skills &amp; Lessons</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Skills &amp; Lessons</h1>
                <p>The courses members learn from in the app. Open a skill to manage its levels, lessons and quizzes.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.catalog-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <form method="GET" action="<?php echo e(route('admin.skills')); ?>" class="ll-toolbar">
                        <div class="ll-search">
                            <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Search skills" aria-label="Search skills">
                            <select name="category" aria-label="Category">
                                <option value="">All categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php if($category === (string) $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <option value="none" <?php if($category === 'none'): echo 'selected'; endif; ?>>No category</option>
                            </select>
                            <select name="status" aria-label="Status">
                                <option value="">Any status</option>
                                <option value="active" <?php if($status === 'active'): echo 'selected'; endif; ?>>Active</option>
                                <option value="inactive" <?php if($status === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                            </select>
                            <button type="submit" class="table-btn">Filter</button>
                            <?php if($search !== '' || $category !== '' || $status !== ''): ?>
                                <a href="<?php echo e(route('admin.skills')); ?>" class="table-btn ll-link">Clear</a>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('admin.skills.create', ctype_digit($category) ? ['category' => $category] : [])); ?>" class="settings-save-btn ll-link">+ Add skill</a>
                    </form>

                    <span class="ll-muted">
                        Showing <?php echo e($total); ?> of <?php echo e($allCount); ?> <?php echo e(\Illuminate\Support\Str::plural('skill', $allCount)); ?>

                    </span>

                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <section class="ll-group">
                            <div class="ll-row between">
                                <h3 class="ll-group-title">
                                    <?php if($categoryId === 0): ?> No category <?php else: ?> <?php echo e($names[$categoryId] ?? 'Category'); ?> <?php endif; ?>
                                    <span class="ll-muted">(<?php echo e($skills->count()); ?>)</span>
                                </h3>
                                <?php if($categoryId !== 0): ?>
                                    <a href="<?php echo e(route('admin.skills.create', ['category' => $categoryId])); ?>" class="table-btn ll-link">+ Add skill here</a>
                                <?php endif; ?>
                            </div>

                            <div class="ll-grid">
                                <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($lessonTotal = (int) ($lessonCounts[$skill->id] ?? 0)); ?>
                                    <article class="ll-card">
                                        <div class="ll-row between">
                                            <span class="ll-skill-icon"><?php echo e($skill->icon ?: '📘'); ?></span>
                                            <span class="ll-badge <?php echo e($skill->status); ?>"><?php echo e(ucfirst($skill->status)); ?></span>
                                        </div>
                                        <h3 style="margin-top:10px;"><?php echo e($skill->title); ?></h3>
                                        <p><?php echo e(\Illuminate\Support\Str::limit($skill->description ?: 'No description yet.', 90)); ?></p>
                                        <p class="ll-muted">
                                            <?php echo e($skill->levels_count); ?> <?php echo e(\Illuminate\Support\Str::plural('level', $skill->levels_count)); ?>

                                            &middot; <?php echo e($lessonTotal); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $lessonTotal)); ?>

                                            <?php if($lessonTotal === 0): ?><span class="ll-badge pending">Empty</span><?php endif; ?>
                                        </p>
                                        <div class="ll-actions">
                                            <a href="<?php echo e(route('admin.skills.show', $skill)); ?>" class="table-btn ll-link">Manage lessons</a>
                                            <a href="<?php echo e(route('admin.skills.edit', $skill)); ?>" class="table-btn ll-link">Edit</a>
                                        </div>
                                    </article>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ll-card">
                            <h3><?php echo e($allCount === 0 ? 'No skills yet' : 'No skills match'); ?></h3>
                            <?php if($allCount === 0): ?>
                                <p>Add one with “+ Add skill”, or load a ready-made catalog:</p>
                                <p><code>php artisan db:seed --class=SampleCatalogSeeder</code></p>
                            <?php else: ?>
                                <p>Try a different search, or <a href="<?php echo e(route('admin.skills')); ?>">clear the filters</a>.</p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/skills/index.blade.php ENDPATH**/ ?>