<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Notifications</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Notifications</h1>
                <p>Your own alerts are kept apart from what members receive in the app.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-tabs">
                        <a class="ll-tab <?php echo e($tab === 'attention' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => 'attention'])); ?>">For you (<?php echo e($attentionTotal); ?>)</a>
                        <a class="ll-tab <?php echo e($tab === 'sent' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => 'sent'])); ?>">Sent to members (<?php echo e($sentCount); ?>)</a>
                        <a class="ll-tab <?php echo e($tab === 'activity' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => 'activity'])); ?>">Member activity (<?php echo e($activityCount); ?>)</a>
                    </div>

                    <?php if($tab === 'attention'): ?>
                        <p class="ll-muted">Work waiting for an administrator. These update by themselves as you clear them.</p>
                        <div class="ll-grid">
                            <?php $__currentLoopData = $attention; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="ll-card">
                                    <div class="ll-row between">
                                        <h3><?php echo e($item['label']); ?></h3>
                                        <span class="ll-badge <?php echo e($item['count'] > 0 ? 'pending' : 'completed'); ?>"><?php echo e($item['count']); ?></span>
                                    </div>
                                    <p class="ll-muted"><?php echo e($item['hint']); ?></p>
                                    <div class="ll-actions">
                                        <a class="settings-save-btn ll-link" href="<?php echo e($item['url']); ?>"><?php echo e($item['count'] > 0 ? 'Review' : 'Open'); ?></a>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <?php if($tab === 'sent'): ?>
                            <div class="ll-card">
                                <h3>Send a notice</h3>
                                <p class="ll-muted">Shows up in the member's app under the Admin tab.</p>
                                <form method="POST" action="<?php echo e(route('admin.notifications.store')); ?>" class="ll-form">
                                    <?php echo csrf_field(); ?>
                                    <div>
                                        <label for="user_id">Recipient</label>
                                        <select name="user_id" id="user_id" required>
                                            <option value="">Choose a member</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php if(old('user_id') == $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="title">Title</label>
                                        <input type="text" name="title" id="title" maxlength="150" value="<?php echo e(old('title')); ?>" required>
                                    </div>
                                    <div>
                                        <label for="message">Message</label>
                                        <textarea name="message" id="message" rows="3" maxlength="500" required><?php echo e(old('message')); ?></textarea>
                                    </div>
                                    <div><button type="submit" class="settings-save-btn">Send notice</button></div>
                                </form>
                            </div>
                        <?php else: ?>
                            <p class="ll-muted">Alerts members got from each other or the app (a coach adding a lesson, a lesson confirmed). They appear under Activity in the app, not Admin.</p>
                        <?php endif; ?>

                        <div class="ll-tabs">
                            <a class="ll-tab <?php echo e($status === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => $tab, 'read' => 'all'])); ?>">All</a>
                            <a class="ll-tab <?php echo e($status === 'unread' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => $tab, 'read' => 'unread'])); ?>">Unread</a>
                            <a class="ll-tab <?php echo e($status === 'read' ? 'active' : ''); ?>" href="<?php echo e(route('admin.notifications', ['tab' => $tab, 'read' => 'read'])); ?>">Read</a>
                        </div>

                        <div class="ll-card">
                            <table class="ll-table">
                                <thead>
                                    <tr>
                                        <th>Member</th>
                                        <th>Title</th>
                                        <th>Message</th>
                                        <th>Sent</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($notification->user?->name ?? 'Deleted user'); ?></td>
                                        <td><strong><?php echo e($notification->title); ?></strong></td>
                                        <td><?php echo e(\Illuminate\Support\Str::limit($notification->message, 70)); ?></td>
                                        <td><?php echo e($notification->created_at->diffForHumans()); ?></td>
                                        <td><span class="ll-badge <?php echo e($notification->read_at ? 'completed' : 'pending'); ?>"><?php echo e($notification->read_at ? 'Read' : 'Unread'); ?></span></td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('admin.notifications.delete', $notification)); ?>" onsubmit="return confirm('Delete this notification?');">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="delete-btn">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="6" class="ll-muted">Nothing here.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php echo e($notifications->links('vendor.pagination.admin')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/notifications.blade.php ENDPATH**/ ?>