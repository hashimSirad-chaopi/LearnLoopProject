
<nav class="ll-crumbs" aria-label="Breadcrumb">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(! $loop->last && isset($item[1])): ?>
            <a href="<?php echo e($item[1]); ?>"><?php echo e($item[0]); ?></a><span>&rsaquo;</span>
        <?php else: ?>
            <strong><?php echo e($item[0]); ?></strong>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/partials/crumbs.blade.php ENDPATH**/ ?>