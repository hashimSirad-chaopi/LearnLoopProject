<?php $editing = $lesson->exists; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - <?php echo e($editing ? 'Edit' : 'Add'); ?> Lesson</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1><?php echo e($editing ? 'Edit Lesson' : 'Add Lesson'); ?></h1>
                <p><?php echo e($skill->icon); ?> <?php echo e($skill->title); ?></p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <form class="ll-card ll-form" method="POST" enctype="multipart/form-data"
                          action="<?php echo e($editing ? route('admin.skills.lessons.update', [$skill, $lesson]) : route('admin.skills.lessons.store', $skill)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                        <div>
                            <label for="title">Lesson title</label>
                            <input id="title" name="title" type="text" value="<?php echo e(old('title', $lesson->title)); ?>" required>
                        </div>

                        <div>
                            <label for="level">Level</label>
                            <select id="level" name="level">
                                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($level); ?>" <?php echo e(old('level', $levelName) === $level ? 'selected' : ''); ?>><?php echo e(ucfirst($level)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p class="ll-muted">Learners go through Easy, Moderate, Hard, then Expert.</p>
                        </div>

                        <?php $ctype = old('content_type', $lesson->content_type ?: 'text'); ?>
                        <div>
                            <label for="content_type">Lesson type</label>
                            <select id="content_type" name="content_type">
                                <?php $__currentLoopData = ['text' => 'Text', 'file' => 'File (PDF, document, slides)', 'audio' => 'Audio', 'video' => 'Video', 'photo' => 'Photo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($ctype === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p class="ll-muted">Choose how the lesson is delivered. The quiz below works the same for every type.</p>
                            <?php $__errorArgs = ['content_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="ll-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div id="attachment-box" style="display:none;">
                            <label for="attachment">Upload</label>
                            <input id="attachment" name="attachment" type="file">
                            <p class="ll-muted" id="attachment-hint"></p>
                            <?php if($editing && $lesson->attachment_path): ?>
                                <p class="ll-muted">Current file: <a href="<?php echo e($lesson->attachment_url); ?>" target="_blank" rel="noopener"><?php echo e($lesson->attachment_name ?: 'open'); ?></a>. Upload a new one to replace it.</p>
                            <?php endif; ?>
                            <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="ll-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="content" id="content-label">Lesson text (shown before the quiz)</label>
                            <textarea id="content" name="content" rows="8"><?php echo e(old('content', $lesson->content)); ?></textarea>
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="ll-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label>Quiz questions</label>
                            <p class="ll-muted">Four answer options per question. You can put a photo, video or audio clip above any question. Select the circle next to the correct one. The pass mark in the app is 70%.</p>

                            <div id="questions">
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qi => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="ll-question" data-question>
                                        <div class="ll-row between">
                                            <strong data-qnum>Question <?php echo e($loop->iteration); ?></strong>
                                            <button type="button" class="delete-btn" data-remove>Remove</button>
                                        </div>
                                        <div style="margin-top:8px;">
                                            <input type="text" data-field="text" name="questions[<?php echo e($qi); ?>][text]" value="<?php echo e($q['text'] ?? ''); ?>" placeholder="Question text">
                                        </div>
                                        <div style="margin-top:8px;">
                                            <label style="font-weight:600;font-size:13px;">Photo, video or audio above this question (optional)</label>
                                            <?php $keep = $q['keep_media'] ?? ($q['media_path'] ?? null); $mtype = $q['media_type'] ?? null; $murl = $q['media_url'] ?? ($keep ? asset('storage/'.$keep) : null); ?>
                                            <?php if($keep && $murl): ?>
                                                <div style="margin:6px 0;">
                                                    <?php if($mtype === 'photo'): ?> <img src="<?php echo e($murl); ?>" alt="" style="max-height:120px;border-radius:8px;">
                                                    <?php elseif($mtype === 'video'): ?> <video src="<?php echo e($murl); ?>" controls style="max-height:140px;border-radius:8px;"></video>
                                                    <?php elseif($mtype === 'audio'): ?> <audio src="<?php echo e($murl); ?>" controls></audio>
                                                    <?php endif; ?>
                                                    <input type="hidden" data-field="keep_media" name="questions[<?php echo e($qi); ?>][keep_media]" value="<?php echo e($keep); ?>">
                                                    <label style="display:block;font-size:12.5px;"><input type="checkbox" data-field="remove_media" name="questions[<?php echo e($qi); ?>][remove_media]" value="1"> Remove this file</label>
                                                </div>
                                            <?php endif; ?>
                                            <input type="file" data-field="media" name="questions[<?php echo e($qi); ?>][media]" accept="image/*,video/*,audio/*">
                                            <?php $__errorArgs = ["questions.$qi.media"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="ll-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php for($oi = 0; $oi < 4; $oi++): ?>
                                            <div class="ll-option">
                                                <input type="radio" data-field="correct" name="questions[<?php echo e($qi); ?>][correct]" value="<?php echo e($oi); ?>" <?php echo e((int) ($q['correct'] ?? 0) === $oi ? 'checked' : ''); ?>>
                                                <input type="text" data-field="option" data-oi="<?php echo e($oi); ?>" name="questions[<?php echo e($qi); ?>][options][<?php echo e($oi); ?>]" value="<?php echo e($q['options'][$oi] ?? ''); ?>" placeholder="Option <?php echo e($oi + 1); ?>">
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <button type="button" class="table-btn" id="add-question">+ Add question</button>
                        </div>

                        <div class="settings-actions">
                            <a href="<?php echo e(route('admin.skills.show', $skill)); ?>" class="table-btn ll-link">Cancel</a>
                            <button type="submit" class="settings-save-btn"><?php echo e($editing ? 'Save Lesson' : 'Add Lesson'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
</div>


<template id="question-template">
    <div class="ll-question" data-question>
        <div class="ll-row between">
            <strong data-qnum>Question</strong>
            <button type="button" class="delete-btn" data-remove>Remove</button>
        </div>
        <div style="margin-top:8px;">
            <input type="text" data-field="text" name="questions[__I__][text]" placeholder="Question text">
        </div>
        <div style="margin-top:8px;">
            <label style="font-weight:600;font-size:13px;">Photo, video or audio above this question (optional)</label>
            <input type="file" data-field="media" name="questions[__I__][media]" accept="image/*,video/*,audio/*">
        </div>
        <?php for($oi = 0; $oi < 4; $oi++): ?>
            <div class="ll-option">
                <input type="radio" data-field="correct" name="questions[__I__][correct]" value="<?php echo e($oi); ?>" <?php echo e($oi === 0 ? 'checked' : ''); ?>>
                <input type="text" data-field="option" data-oi="<?php echo e($oi); ?>" name="questions[__I__][options][<?php echo e($oi); ?>]" placeholder="Option <?php echo e($oi + 1); ?>">
            </div>
        <?php endfor; ?>
    </div>
</template>

<script>
(function () {
    var list = document.getElementById('questions');
    var tpl = document.getElementById('question-template');

    // Rename every field so the indexes are 0,1,2... with no gaps.
    function renumber() {
        var cards = list.querySelectorAll('[data-question]');
        cards.forEach(function (card, i) {
            card.querySelector('[data-qnum]').textContent = 'Question ' + (i + 1);
            card.querySelectorAll('[data-field]').forEach(function (el) {
                var kind = el.getAttribute('data-field');
                if (kind === 'text') el.name = 'questions[' + i + '][text]';
                if (kind === 'correct') el.name = 'questions[' + i + '][correct]';
                if (kind === 'media') el.name = 'questions[' + i + '][media]';
                if (kind === 'keep_media') el.name = 'questions[' + i + '][keep_media]';
                if (kind === 'remove_media') el.name = 'questions[' + i + '][remove_media]';
                if (kind === 'option') el.name = 'questions[' + i + '][options][' + el.getAttribute('data-oi') + ']';
            });
        });
    }

    document.getElementById('add-question').addEventListener('click', function () {
        if (list.querySelectorAll('[data-question]').length >= 10) { alert('A lesson can have up to 10 questions.'); return; }
        list.insertAdjacentHTML('beforeend', tpl.innerHTML.replace(/__I__/g, '0'));
        renumber();
    });

    list.addEventListener('click', function (e) {
        if (!e.target.hasAttribute('data-remove')) return;
        if (list.querySelectorAll('[data-question]').length <= 1) { alert('A lesson needs at least one question.'); return; }
        e.target.closest('[data-question]').remove();
        renumber();
    });

    renumber();

    // The lesson type decides whether there is an upload, and what it accepts.
    var typeSelect = document.getElementById('content_type');
    var box = document.getElementById('attachment-box');
    var input = document.getElementById('attachment');
    var hint = document.getElementById('attachment-hint');
    var label = document.getElementById('content-label');
    var rules = {
        file:  { accept: '.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.zip,.csv', hint: 'PDF, Word, PowerPoint, Excel, text, CSV or ZIP. Up to 20 MB.' },
        audio: { accept: 'audio/*', hint: 'MP3, M4A, AAC, WAV or OGG. Up to 30 MB.' },
        video: { accept: 'video/*', hint: 'MP4, MOV, M4V or WEBM. Up to 50 MB.' },
        photo: { accept: 'image/*', hint: 'JPG, PNG or WEBP. Up to 10 MB.' }
    };
    function syncType() {
        var t = typeSelect.value, r = rules[t];
        box.style.display = r ? '' : 'none';
        if (r) { input.accept = r.accept; hint.textContent = r.hint; }
        label.textContent = t === 'text' ? 'Lesson text (shown before the quiz)' : 'Short note for the learner (optional)';
        document.getElementById('content').required = (t === 'text');
    }
    typeSelect.addEventListener('change', syncType);
    syncType();
})();
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/lessons/form.blade.php ENDPATH**/ ?>