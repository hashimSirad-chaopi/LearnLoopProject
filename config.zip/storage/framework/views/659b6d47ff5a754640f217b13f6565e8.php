<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Comments</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <style>
        .cmt-text, .cmt-short, .cmt-full { white-space: pre-line; overflow-wrap: anywhere; }
        .cmt .cmt-full { display: none; }
        .cmt.open .cmt-full { display: block; }
        .cmt.open .cmt-short { display: none; }
        .cmt-toggle { background: none; border: 0; padding: 4px 0 0; cursor: pointer; color: #1f6f4a; font-weight: 700; font-size: 12.5px; }
        .cmt-toggle:hover { text-decoration: underline; }
        .cmt-toggle:focus:not(:focus-visible) { outline: none; box-shadow: none; }
        .cmt-len { color: #6b7780; font-size: 11.5px; margin-left: 6px; }
        .cmt-tools { display: flex; gap: 12px; align-items: center; }
        .cmt-tools button { background: none; border: 0; padding: 0; cursor: pointer; color: #1f6f4a; font-weight: 700; font-size: 12.5px; }
        .cmt-tools button:hover { text-decoration: underline; }
        tr:has(.bulk-check:checked) { background: #f1f8f4; }
        .bulk-bar { position: sticky; top: 0; z-index: 5; flex-wrap: wrap; row-gap: 8px; background: #fff; box-shadow: 0 2px 8px rgba(0, 0, 0, .06); }
        .bulk-bar .bulk-actions { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }

        /* Comments table: the Comment column gets the free space (the shared user-table rules give it to column 2) */
        .users-table.um-table.cm-table { min-width: 900px; }
        .users-table.um-table.cm-table th:nth-child(2),
        .users-table.um-table.cm-table td:nth-child(2) { width: 160px; min-width: 140px; white-space: normal; }
        .users-table.um-table.cm-table th:nth-child(3),
        .users-table.um-table.cm-table td:nth-child(3) { width: 100%; min-width: 320px; white-space: normal; }
        .users-table.um-table.cm-table th { vertical-align: middle; }
        .users-table.um-table.cm-table td.um-hide-sm.cm-listing { white-space: normal; min-width: 150px; max-width: 220px; }
        .users-table.um-table.cm-table td { vertical-align: top; }
        .users-table.um-table.cm-table td.um-check { padding-top: 16px; }
        .users-table.um-table.cm-table td.um-actions-col .um-actions { align-items: center; gap: 6px; }
    </style>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Comments</h1>
                <p>What users write under listings in the app. Remove anything that breaks the rules; the user is told why.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    
                    <div class="um-stats">
                        <a class="um-stat <?php echo e($type === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('admin.comments', array_filter(['search' => $search]))); ?>">
                            <span class="um-stat-label">All</span>
                            <strong><?php echo e(number_format($counts['all'])); ?></strong>
                        </a>
                        <a class="um-stat <?php echo e($type === 'comments' ? 'active' : ''); ?>" href="<?php echo e(route('admin.comments', array_filter(['search' => $search, 'type' => 'comments']))); ?>">
                            <span class="um-stat-label">Comments</span>
                            <strong><?php echo e(number_format($counts['comments'])); ?></strong>
                        </a>
                        <a class="um-stat <?php echo e($type === 'replies' ? 'active' : ''); ?>" href="<?php echo e(route('admin.comments', array_filter(['search' => $search, 'type' => 'replies']))); ?>">
                            <span class="um-stat-label">Replies</span>
                            <strong><?php echo e(number_format($counts['replies'])); ?></strong>
                        </a>
                        <div class="um-stat plain">
                            <span class="um-stat-label">Written today</span>
                            <strong><?php echo e(number_format($counts['today'])); ?></strong>
                        </div>
                    </div>

                    <form method="GET" action="<?php echo e(route('admin.comments')); ?>" class="ll-search grow">
                        <?php if($type !== 'all'): ?><input type="hidden" name="type" value="<?php echo e($type); ?>"><?php endif; ?>
                        <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search comment text, user or listing" aria-label="Search comments">
                        <button type="submit" class="table-btn">Search</button>
                        <?php if($search !== ''): ?>
                            <a href="<?php echo e(route('admin.comments', array_filter(['type' => $type !== 'all' ? $type : null]))); ?>" class="table-btn ll-link">Clear</a>
                        <?php endif; ?>
                    </form>

                    <span class="ll-row between">
                    <span class="ll-muted">
                        <?php echo e(number_format($comments->total())); ?> <?php echo e(\Illuminate\Support\Str::plural('comment', $comments->total())); ?>

                        <?php if($type !== 'all'): ?> &middot; <?php echo e($type); ?> only <?php endif; ?>
                        <?php if($search !== ''): ?> &middot; matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                    </span>
                    <span class="cmt-tools">
                        <button type="button" data-cmt-all="open">Expand all</button>
                        <button type="button" data-cmt-all="close">Collapse all</button>
                    </span>
                    </span>

                    
                    <?php if($comments->isNotEmpty()): ?>
                        <form id="bulk-comments" method="POST" action="<?php echo e(route('admin.comments.bulk')); ?>" class="bulk-bar">
                            <?php echo csrf_field(); ?>
                            <label class="bulk-all"><input type="checkbox" data-select-all="bulk-comments"> Select all on this page (<?php echo e($comments->count()); ?>)</label>
                            <span class="bulk-count"></span>

                            <span class="bulk-actions">
                                <strong>Remove</strong>
                                <select name="reason" aria-label="Reason for removing the selected comments">
                                    <?php $__currentLoopData = $reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" name="action" value="remove" class="table-btn" onclick="return confirm('Remove the selected comments, and any replies under them? Each user is told why.');">Remove selected</button>
                            </span>

                            <span class="bulk-actions">
                                <strong>Suspend the authors</strong>
                                <select name="duration" aria-label="Suspend the authors for">
                                    <?php $__currentLoopData = \App\Support\Suspension::OPTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key === '1w' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="suspend_reason" aria-label="Reason for suspending">
                                    <?php $__currentLoopData = \App\Support\Suspension::REASONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key === 'rules' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="text" name="note" maxlength="500" placeholder='Details (required for "Other")' aria-label="Details">
                                <button type="submit" name="action" value="suspend" class="table-btn" onclick="return confirm('Suspend the authors of the selected comments? Their comments stay. Admins, yourself and users already suspended are skipped.');">Suspend authors</button>
                                <button type="submit" name="action" value="both" class="table-btn" onclick="return confirm('Suspend the authors AND remove the selected comments (and replies under them)? Each user is told why.');">Remove &amp; suspend</button>
                            </span>
                        </form>
                    <?php endif; ?>

                    
                    <div class="users-table-container um-table-wrap">
                        <table class="users-table um-table cm-table">
                            <thead>
                                <tr>
                                    <th class="um-check"></th>
                                    <th>User</th>
                                    <th>Comment</th>
                                    <th class="um-hide-sm">On listing</th>
                                    <th class="um-hide-sm">When</th>
                                    <th class="um-actions-col">Remove</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr id="comment-<?php echo e($comment->id); ?>">
                                        <td class="um-check">
                                            <input type="checkbox" name="ids[]" value="<?php echo e($comment->id); ?>" form="bulk-comments" class="bulk-check" aria-label="Select comment by <?php echo e($comment->user?->name ?? 'a deleted user'); ?>">
                                        </td>

                                        <td>
                                            <?php if($comment->user): ?>
                                                <a href="<?php echo e(route('admin.users.show', $comment->user)); ?>" class="cell-link"><strong><?php echo e($comment->user->name); ?></strong></a>
                                                <?php if($comment->user->status === 'suspended'): ?><br><span class="status-badge suspended-status">Suspended</span><?php endif; ?>
                                            <?php else: ?>
                                                <strong>Deleted user</strong>
                                            <?php endif; ?>
                                        </td>

                                        <td class="cm-comment">
                                            <?php if($comment->parent_id): ?><span class="ll-badge">Reply</span><?php endif; ?>
                                            <?php if($comment->parent): ?>
                                                <small class="ll-muted" style="display:block;border-left:3px solid #d8dee4;padding-left:8px;margin:4px 0;">
                                                    Replying to <?php echo e($comment->parent->user?->name ?? 'a user'); ?>: &ldquo;<?php echo e(\Illuminate\Support\Str::limit($comment->parent->body, 70)); ?>&rdquo;
                                                </small>
                                            <?php endif; ?>
                                <?php if(mb_strlen($comment->body) > 300): ?>
                                                <div class="cmt" data-cmt="<?php echo e($comment->id); ?>">
                                                    <div class="cmt-short"><?php echo e(\Illuminate\Support\Str::limit($comment->body, 300)); ?></div>
                                                    <div class="cmt-full"><?php echo e($comment->body); ?></div>
                                                    <button type="button" class="cmt-toggle" data-cmt-toggle>See more</button>
                                                    <span class="cmt-len"><?php echo e(number_format(mb_strlen($comment->body))); ?> characters</span>
                                                </div>
                                            <?php else: ?>
                                                <div class="cmt-text"><?php echo e($comment->body); ?></div>
                                            <?php endif; ?>
                                            <?php if($comment->replies_count > 0): ?>
                                                <small class="ll-muted"><?php echo e($comment->replies_count); ?> <?php echo e(\Illuminate\Support\Str::plural('reply', $comment->replies_count)); ?></small>
                                            <?php endif; ?>
                                        </td>

                                        <td class="um-hide-sm cm-listing">
                                            <?php if($comment->listing): ?>
                                                <a href="<?php echo e(route('admin.listings.edit', $comment->listing)); ?>" class="cell-link"><?php echo e(\Illuminate\Support\Str::limit($comment->listing->title, 40)); ?></a>
                                            <?php else: ?>
                                                <span class="ll-muted">Deleted listing</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="um-hide-sm" title="<?php echo e($comment->created_at->format('M j, Y g:i A')); ?>"><?php echo e($comment->created_at->diffForHumans()); ?></td>

                                        <td class="um-actions-col">
                                            <form method="POST" action="<?php echo e(route('admin.comments.delete', $comment)); ?>" class="um-actions"
                                                  onsubmit="return confirm('<?php echo e($comment->replies_count > 0 ? 'Remove this comment and its '.$comment->replies_count.' '.\Illuminate\Support\Str::plural('reply', $comment->replies_count).'?' : 'Remove this comment?'); ?>');">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <select name="reason" class="lr-select" aria-label="Reason for removing this comment">
                                                    <?php $__currentLoopData = $reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button type="submit" class="delete-btn">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="empty-users">
                                            <?php echo e($search !== '' || $type !== 'all' ? 'Nothing matches these filters.' : 'Nobody has commented on a listing yet.'); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($comments->links('vendor.pagination.admin')); ?>

                </div>
            </div>
        </section>
    </main>
</div>

<script>
    // See more / See less on long comments. Opened comments stay open when the page refreshes itself.
    (function () {
        var opened = new Set();

        function apply() {
            document.querySelectorAll('.cmt[data-cmt]').forEach(function (el) {
                var isOpen = opened.has(el.dataset.cmt);
                el.classList.toggle('open', isOpen);
                var button = el.querySelector('[data-cmt-toggle]');
                if (button) button.textContent = isOpen ? 'See less' : 'See more';
            });
        }

        document.addEventListener('click', function (event) {
            var toggle = event.target.closest('[data-cmt-toggle]');
            if (toggle) {
                var id = toggle.closest('.cmt').dataset.cmt;
                if (opened.has(id)) opened.delete(id); else opened.add(id);
                apply();
                return;
            }
            var all = event.target.closest('[data-cmt-all]');
            if (all) {
                document.querySelectorAll('.cmt[data-cmt]').forEach(function (el) {
                    if (all.dataset.cmtAll === 'open') opened.add(el.dataset.cmt); else opened.delete(el.dataset.cmt);
                });
                apply();
            }
        });

        document.addEventListener('live:updated', apply);
    })();
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/comments.blade.php ENDPATH**/ ?>