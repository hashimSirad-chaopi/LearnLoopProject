<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Recovery Requests</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .lr-avatar { border-radius: 11px; }
        .lr-avatar-lg { border-radius: 14px; }
    </style>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Recovery Requests</h1>
                <p>Suspended members cannot log in, so they ask you from the app's login screen. Reactivate the account, or decline and tell them why.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-tabs">
                        <a class="ll-tab <?php echo e($status === 'pending' ? 'active' : ''); ?>" href="<?php echo e(route('admin.appeals')); ?>">Pending (<?php echo e($counts['pending']); ?>)</a>
                        <a class="ll-tab <?php echo e($status === 'approved' ? 'active' : ''); ?>" href="<?php echo e(route('admin.appeals', ['status' => 'approved'])); ?>">Reactivated (<?php echo e($counts['approved']); ?>)</a>
                        <a class="ll-tab <?php echo e($status === 'declined' ? 'active' : ''); ?>" href="<?php echo e(route('admin.appeals', ['status' => 'declined'])); ?>">Declined (<?php echo e($counts['declined']); ?>)</a>
                    </div>

                    <?php $__empty_1 = true; $__currentLoopData = $appeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appeal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($member = $appeal->user); ?>
                        <div class="ll-card">
                            <div class="lr-appeal-head">
                                <a href="<?php echo e(route('admin.users.show', $member)); ?>" class="lr-member">
                                    <?php echo $__env->make('partials.avatar', ['user' => $member, 'class' => 'lr-avatar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <span class="lr-member-text">
                                        <strong><?php echo e($member->name); ?></strong>
                                        <small><?php echo e($member->email); ?></small>
                                    </span>
                                </a>
                                <div class="ll-row">
                                    <span class="ll-badge <?php echo e($member->status === 'active' ? 'published' : 'rejected'); ?>">Account <?php echo e($member->status); ?></span>
                                    <?php if(($upheld[$member->id] ?? 0) > 0): ?>
                                        <span class="ll-badge pending"><?php echo e($upheld[$member->id]); ?> upheld <?php echo e(\Illuminate\Support\Str::plural('report', $upheld[$member->id])); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if($why = \App\Support\Suspension::describe($member->suspension_reason, $member->suspension_note)): ?>
                                <p class="ll-muted"><strong>Suspended for:</strong> <?php echo e($why); ?></p>
                            <?php endif; ?>
                            <p class="ll-muted">Sent <?php echo e($appeal->created_at->diffForHumans()); ?> &middot; <?php echo e($appeal->created_at->format('M d, Y g:i A')); ?></p>
                            <blockquote class="lr-quote"><?php echo e($appeal->message); ?></blockquote>

                            <?php if($appeal->status === 'pending'): ?>
                                <form method="POST" class="lr-decision">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <label for="note-<?php echo e($appeal->id); ?>" class="ll-muted">Note to the member (required to decline, optional to reactivate)</label>
                                    <textarea id="note-<?php echo e($appeal->id); ?>" name="note" rows="2" maxlength="500" class="lr-note" placeholder="For example: Thanks for explaining, please follow the community rules."></textarea>
                                    <div class="ll-row">
                                        <button type="submit" formaction="<?php echo e(route('admin.appeals.approve', $appeal)); ?>" class="table-btn"
                                                onclick="return confirm('Reactivate <?php echo e(addslashes($member->name)); ?>\'s account?');">Reactivate account</button>
                                        <button type="submit" formaction="<?php echo e(route('admin.appeals.decline', $appeal)); ?>" class="table-btn ll-link"
                                                onclick="var n = this.form.note; if (!n.value.trim()) { n.focus(); alert('Write a short reason so the member knows why.'); return false; } return confirm('Decline this request?');">Decline</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <p class="ll-muted">
                                    <strong><?php echo e($appeal->status === 'approved' ? 'Reactivated' : 'Declined'); ?></strong>
                                    by <?php echo e($appeal->reviewer->name ?? 'an administrator'); ?>

                                    <?php echo e($appeal->reviewed_at ? $appeal->reviewed_at->diffForHumans() : ''); ?>

                                    <?php if($appeal->admin_note): ?> &middot; &ldquo;<?php echo e($appeal->admin_note); ?>&rdquo; <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ll-card"><p class="ll-muted">
                            <?php echo e($status === 'pending' ? 'No recovery requests are waiting. 🎉' : 'Nothing here yet.'); ?>

                        </p></div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/appeals.blade.php ENDPATH**/ ?>