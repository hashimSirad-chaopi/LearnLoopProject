<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Lesson Review</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .lr-avatar { border-radius: 11px; }
        .lr-avatar-lg { border-radius: 14px; }
    </style>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Lesson Review</h1>
                <p>Lessons members wrote in the app (Profile → My Lessons). Nothing goes live until you approve it, unless the author is trusted in that skill.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.catalog-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-tabs">
                        <a class="ll-tab <?php echo e($status === 'users' ? 'active' : ''); ?>" href="<?php echo e(route('admin.lessons')); ?>">Users</a>
                        <a class="ll-tab <?php echo e($status === 'pending' ? 'active' : ''); ?>" href="<?php echo e(route('admin.lessons', ['status' => 'pending'])); ?>">Pending (<?php echo e($counts['pending']); ?>)</a>
                        <a class="ll-tab <?php echo e($status === 'published' ? 'active' : ''); ?>" href="<?php echo e(route('admin.lessons', ['status' => 'published'])); ?>">Published (<?php echo e($counts['published']); ?>)</a>
                        <a class="ll-tab <?php echo e($status === 'rejected' ? 'active' : ''); ?>" href="<?php echo e(route('admin.lessons', ['status' => 'rejected'])); ?>">Need change (<?php echo e($counts['rejected']); ?>)</a>
                    </div>

                    <?php if($status === 'users'): ?>

                        
                        <div class="ll-toolbar">
                            <form method="GET" action="<?php echo e(route('admin.lessons')); ?>" class="ll-search">
                                <input type="text" inputmode="search" name="search" value="<?php echo e($search); ?>" placeholder="Search members by name or email" aria-label="Search members">
                                <button type="submit" class="table-btn">Search</button>
                                <?php if($search !== ''): ?>
                                    <a href="<?php echo e(route('admin.lessons')); ?>" class="table-btn ll-link">Clear</a>
                                <?php endif; ?>
                            </form>
                        </div>

                        <span class="ll-muted">
                            <?php echo e($members->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('member', $members->count())); ?> with lessons
                            <?php if($search !== ''): ?> &middot; matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                            &middot; members with lessons waiting for review are listed first
                        </span>

                        <div class="ll-card">
                            <table class="ll-table">
                                <thead>
                                    <tr>
                                        <th>Member</th>
                                        <th>Lessons</th>
                                        <th>Pending</th>
                                        <th>Published</th>
                                        <th>Need change</th>
                                        <th>Last submitted</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php ($row = $stats[$member->id]); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('admin.lessons.member', $member)); ?>" class="lr-member">
                                                <?php echo $__env->make('partials.avatar', ['user' => $member, 'class' => 'lr-avatar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                <span class="lr-member-text">
                                                    <strong><?php echo e($member->name); ?></strong>
                                                    <small><?php echo e($member->email); ?></small>
                                                </span>
                                            </a>
                                        </td>
                                        <td><?php echo e((int) $row->total); ?></td>
                                        <td><?php if((int) $row->pending > 0): ?><span class="ll-badge pending"><?php echo e((int) $row->pending); ?></span><?php else: ?><span class="ll-muted">0</span><?php endif; ?></td>
                                        <td><?php if((int) $row->published > 0): ?><span class="ll-badge published"><?php echo e((int) $row->published); ?></span><?php else: ?><span class="ll-muted">0</span><?php endif; ?></td>
                                        <td><?php if((int) $row->rejected > 0): ?><span class="ll-badge rejected"><?php echo e((int) $row->rejected); ?></span><?php else: ?><span class="ll-muted">0</span><?php endif; ?></td>
                                        <td class="ll-muted" style="white-space:nowrap;"><?php echo e($row->last_at ? \Illuminate\Support\Carbon::parse($row->last_at)->diffForHumans() : '—'); ?></td>
                                        <td class="lr-right"><a href="<?php echo e(route('admin.lessons.member', $member)); ?>" class="table-btn ll-link">View lessons &rsaquo;</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="7"><?php echo e($search !== '' ? 'No members match your search.' : 'No member has written a lesson yet.'); ?></td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        
                        <div class="ll-toolbar">
                            <form method="GET" action="<?php echo e(route('admin.lessons')); ?>" class="ll-search">
                                <input type="hidden" name="status" value="<?php echo e($status); ?>">
                                <input type="text" inputmode="search" name="search" value="<?php echo e($search); ?>" placeholder="Search lesson, skill or author" aria-label="Search lessons">
                                <button type="submit" class="table-btn">Search</button>
                                <?php if($search !== ''): ?>
                                    <a href="<?php echo e(route('admin.lessons', ['status' => $status])); ?>" class="table-btn ll-link">Clear</a>
                                <?php endif; ?>
                            </form>
                        </div>
                        <span class="ll-muted">
                            <?php echo e($lessons->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('lesson', $lessons->count())); ?>

                            <?php if($search !== ''): ?> &middot; matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                        </span>

                        <div class="ll-card">
                            <table class="ll-table">
                                <thead>
                                    <tr>
                                        <th>Lesson</th>
                                        <th>Skill · level</th>
                                        <th>Author</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><strong><?php echo e($lesson->title); ?></strong></td>
                                        <td><?php echo e($lesson->skillLevel?->skill?->title ?? 'Unknown skill'); ?> · <?php echo e(ucfirst($lesson->skillLevel?->name ?? '')); ?></td>
                                        <td>
                                            <?php if($lesson->author): ?>
                                                <a href="<?php echo e(route('admin.lessons.member', $lesson->author)); ?>" class="lr-member">
                                                    <?php echo $__env->make('partials.avatar', ['user' => $lesson->author, 'class' => 'lr-avatar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                    <span class="lr-member-text"><strong><?php echo e($lesson->author->name); ?></strong></span>
                                                </a>
                                            <?php else: ?>
                                                Deleted user
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="ll-badge <?php echo e($lesson->status); ?>"><?php echo e($lesson->status === 'rejected' ? 'Needs changes' : ucfirst($lesson->status)); ?></span>
                                            <?php if($lesson->status === 'published' && ! $lesson->approved_by): ?>
                                                <span class="ll-badge trusted" title="Published automatically because the author is trusted in this skill. Does not count toward trust.">Auto</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($lesson->created_at->diffForHumans()); ?></td>
                                        <td><a href="<?php echo e(route('admin.lessons.show', $lesson)); ?>" class="table-btn ll-link"><?php echo e($lesson->status === 'pending' ? 'Review' : 'View'); ?></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="6"><?php echo e($search !== '' ? 'No lessons match your search.' : 'Nothing here. '.($status === 'pending' ? 'No lessons are waiting for review.' : '')); ?></td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/lessons/index.blade.php ENDPATH**/ ?>