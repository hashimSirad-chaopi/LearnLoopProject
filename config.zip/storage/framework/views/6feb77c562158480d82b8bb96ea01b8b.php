
<?php ($pendingMemberLessons = \App\Models\Lesson::whereNotNull('author_id')->where('status', 'pending')->count()); ?>

<div class="ll-catalog-nav">
    <div class="ll-tabs">
        <a class="ll-tab <?php echo e(request()->routeIs('admin.categories*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories')); ?>">1. Categories</a>
        <a class="ll-tab <?php echo e(request()->routeIs('admin.skills*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.skills')); ?>">2. Skills &amp; lessons</a>
        <a class="ll-tab <?php echo e(request()->routeIs('admin.lessons*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.lessons')); ?>">
            3. User lessons
            <?php if($pendingMemberLessons > 0): ?><span class="nav-count"><?php echo e($pendingMemberLessons); ?></span><?php endif; ?>
        </a>
    </div>
    <p class="ll-flow">
        <strong>How it fits together:</strong>
        a <em>category</em> groups skills &rarr; a <em>skill</em> has levels (easy to expert) &rarr; each level holds <em>lessons</em> &rarr; each lesson has a short quiz.
        Lessons users write themselves are reviewed in step 3.
    </p>
</div>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/partials/catalog-tabs.blade.php ENDPATH**/ ?>