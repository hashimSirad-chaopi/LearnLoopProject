<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Professional Verification</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Professional Verification</h1>
                <p>Members who say they already work with a skill send proof and pass a hard quiz in the app. Check the proof, then approve or decline. Everyone else earns their teaching level by passing lessons.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="ll-tabs">
                        <?php $__currentLoopData = ['in_review' => 'Waiting for you', 'approved' => 'Approved', 'rejected' => 'Declined', 'quiz' => 'Taking the quiz', 'failed' => 'Failed the quiz']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="ll-tab <?php echo e($status === $key ? 'active' : ''); ?>" href="<?php echo e(route('admin.professional', ['status' => $key])); ?>"><?php echo e($label); ?> (<?php echo e((int) ($counts[$key] ?? 0)); ?>)</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="ll-card">
                            <div class="ll-row between">
                                <div>
                                    <h3><?php echo e($row->user?->name ?? 'Deleted user'); ?> <span class="ll-muted">· <?php echo e($row->skill?->icon); ?> <?php echo e($row->skill?->title); ?></span></h3>
                                    <p class="ll-muted" style="margin:0;">
                                        <?php echo e($row->user?->email); ?> · sent <?php echo e($row->updated_at->diffForHumans()); ?>

                                        <?php if($row->quiz_total): ?> · hard quiz <?php echo e($row->quiz_score); ?>/<?php echo e($row->quiz_total); ?> (pass mark <?php echo e(\App\Models\ProfessionalVerification::passMark($row->quiz_total)); ?>) <?php endif; ?>
                                        <?php if($row->attempts > 1): ?> · <?php echo e($row->attempts); ?> attempts <?php endif; ?>
                                    </p>
                                </div>
                                <span class="ll-badge <?php echo e($row->status === 'approved' ? 'published' : ($row->status === 'in_review' ? 'pending' : ($row->status === 'rejected' ? 'rejected' : 'pending'))); ?>">
                                    <?php echo e(['in_review' => 'Waiting', 'approved' => 'Approved', 'rejected' => 'Declined', 'quiz' => 'Quiz not taken', 'failed' => 'Quiz failed'][$row->status] ?? $row->status); ?>

                                </span>
                            </div>

                            <?php if($row->proof_note): ?>
                                <p style="margin-top:10px;"><strong>Member's note:</strong> <?php echo e($row->proof_note); ?></p>
                            <?php endif; ?>

                            <?php if($row->proof_path): ?>
                                <div style="margin-top:10px;">
                                    <strong>Proof:</strong>
                                    <a href="<?php echo e($row->proof_url); ?>" target="_blank" rel="noopener"><?php echo e($row->proof_name ?: 'Open file'); ?></a>
                                    <?php if($row->proofIsImage()): ?>
                                        <div style="margin-top:8px;"><a href="<?php echo e($row->proof_url); ?>" target="_blank" rel="noopener"><img src="<?php echo e($row->proof_url); ?>" alt="Proof" style="max-width:360px;max-height:260px;border-radius:10px;border:1px solid var(--ll-border);"></a></div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <?php if($row->status === 'rejected' && $row->rejection_reason): ?>
                                <div class="ll-note danger" style="margin-top:10px;"><strong>Declined:</strong> <?php echo e($row->rejection_reason); ?></div>
                            <?php endif; ?>
                            <?php if($row->reviewer): ?>
                                <p class="ll-muted" style="margin-top:8px;">Reviewed by <?php echo e($row->reviewer->name); ?> <?php echo e($row->reviewed_at?->diffForHumans()); ?></p>
                            <?php endif; ?>

                            <?php if(in_array($row->status, ['in_review', 'approved'], true)): ?>
                                <div class="ll-row" style="margin-top:12px; align-items:flex-start;">
                                    <?php if($row->status === 'in_review'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.professional.approve', $row)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="disable-btn">Approve as Professional</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" action="<?php echo e(route('admin.professional.reject', $row)); ?>" class="ll-form" style="flex:1; min-width:260px;">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div>
                                            <label for="reason-<?php echo e($row->id); ?>"><?php echo e($row->status === 'approved' ? 'Take the Professional level away (the member sees this)' : 'Decline (the member sees this and can send new proof)'); ?></label>
                                            <textarea id="reason-<?php echo e($row->id); ?>" name="rejection_reason" rows="2" required placeholder="e.g. The certificate is unreadable. Please send a clearer photo."></textarea>
                                        </div>
                                        <div><button type="submit" class="disable-btn"><?php echo e($row->status === 'approved' ? 'Remove level' : 'Decline'); ?></button></div>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ll-card"><p class="ll-muted">Nothing here.<?php echo e($status === 'in_review' ? ' No proof is waiting for review.' : ''); ?></p></div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/professional/index.blade.php ENDPATH**/ ?>