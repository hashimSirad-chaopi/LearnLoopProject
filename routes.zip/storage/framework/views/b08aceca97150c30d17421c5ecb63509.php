<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Reports</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>

        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Reports</h1>
                <p>Complaints members filed about other members or their listings. Decide what happens: close it, warn the member, or suspend the account.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    
                    <div class="um-stats rp-stats">
                        <?php $__currentLoopData = ['pending' => 'Pending', 'resolved' => 'Resolved', 'dismissed' => 'Dismissed', 'all' => 'All reports']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="um-stat rp-stat-<?php echo e($key); ?> <?php echo e($statusFilter === $key ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.reports', array_filter(['search' => $search, 'status' => $key === 'all' ? null : $key]))); ?>">
                                <span class="um-stat-label"><?php echo e($label); ?></span>
                                <strong><?php echo e(number_format($counts[$key])); ?></strong>
                                <?php if($key === 'pending' && $counts['pending'] > 0): ?><small class="rp-stat-hint">need your review</small><?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    
                    <div class="ll-toolbar">
                        <form method="GET" action="<?php echo e(route('admin.reports')); ?>" class="ll-search">
                            <?php if($statusFilter !== 'all'): ?><input type="hidden" name="status" value="<?php echo e($statusFilter); ?>"><?php endif; ?>
                            <input type="text" inputmode="search" name="search" value="<?php echo e($search); ?>" placeholder="Search by title or reason" aria-label="Search reports">
                            <button type="submit" class="table-btn">Search</button>
                            <?php if($search !== ''): ?>
                                <a href="<?php echo e(route('admin.reports', array_filter(['status' => $statusFilter === 'all' ? null : $statusFilter]))); ?>" class="table-btn ll-link">Clear</a>
                            <?php endif; ?>
                        </form>
                        <span class="ll-muted">
                            <?php echo e($reports->total()); ?> <?php echo e(\Illuminate\Support\Str::plural('report', $reports->total())); ?>

                            <?php if($search !== ''): ?> matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                        </span>
                    </div>

                    
                    <?php if($reports->where('status', 'pending')->isNotEmpty()): ?>
                        <form id="bulk-reports" method="POST" action="<?php echo e(route('admin.reports.bulk')); ?>" class="bulk-bar">
                            <?php echo csrf_field(); ?>
                            <label class="bulk-all"><input type="checkbox" data-select-all="bulk-reports"> Select all pending</label>
                            <span class="bulk-count"></span>
                            <span class="bulk-actions">
                                <button type="submit" name="bulk" value="resolve" class="table-btn" onclick="return confirm('Resolve the selected reports? (No warning or suspension is sent in bulk.)');">Resolve selected</button>
                                <button type="submit" name="bulk" value="dismiss" class="table-btn" onclick="return confirm('Dismiss the selected reports?');">Dismiss selected</button>
                            </span>
                        </form>
                    <?php endif; ?>

                    
                    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $reported = $report->reportedUser;
                            $parts = str_contains($report->reason, ' — ') ? explode(' — ', $report->reason, 2) : [null, $report->reason];
                            [$type, $details] = $parts;
                            $up = (int) ($upheld[$report->reported_user_id] ?? 0);
                            $warn = (int) ($warnings[$report->reported_user_id] ?? 0);
                        ?>

                        <article class="rp-card <?php echo e($report->status); ?>" id="report-<?php echo e($report->id); ?>">
                            <header class="rp-head">
                                <?php if($report->status === 'pending'): ?>
                                    <input type="checkbox" name="ids[]" value="<?php echo e($report->id); ?>" form="bulk-reports" class="bulk-check" aria-label="Select this report">
                                <?php endif; ?>
                                <div class="rp-title">
                                    <h3><?php echo e($report->title); ?></h3>
                                    <span class="ll-muted">Filed by <?php echo e($report->reporter->name ?? 'Unknown'); ?> &middot; <?php echo e($report->created_at->diffForHumans()); ?></span>
                                </div>
                                <span class="rp-badge <?php echo e($report->status); ?>"><?php echo e(ucfirst($report->status)); ?></span>
                            </header>

                            <div class="rp-meta">
                                <span class="rp-chip against">
                                    Against
                                    <?php if($reported): ?>
                                        <a href="<?php echo e(route('admin.users.show', $reported)); ?>"><strong><?php echo e($reported->name); ?></strong></a>
                                    <?php else: ?>
                                        <strong>a deleted member</strong>
                                    <?php endif; ?>
                                </span>
                                <?php if($report->listing): ?>
                                    <span class="rp-chip">Listing: <strong><?php echo e(\Illuminate\Support\Str::limit($report->listing->title, 40)); ?></strong></span>
                                <?php endif; ?>
                                <?php if($type): ?>
                                    <span class="rp-chip type"><?php echo e($type); ?></span>
                                <?php endif; ?>
                                <?php if($reported && $reported->status === 'suspended'): ?>
                                    <span class="status-badge suspended-status">Suspended</span>
                                <?php endif; ?>
                            </div>

                            <blockquote class="lr-quote"><?php echo e($details); ?></blockquote>

                            <?php if($reported): ?>
                                <div class="rp-history" title="Reports an admin upheld against this member. At <?php echo e($autoSuspendAfter); ?> the account is suspended automatically.">
                                    <span class="rp-history-label">Member history</span>
                                    <?php if($autoSuspendAfter > 0): ?>
                                        <span class="rp-pips" aria-hidden="true">
                                            <?php for($i = 1; $i <= $autoSuspendAfter; $i++): ?><i class="rp-pip <?php echo e($i <= $up ? 'on' : ''); ?>"></i><?php endfor; ?>
                                        </span>
                                    <?php endif; ?>
                                    <span><?php echo e($up); ?> upheld <?php echo e(\Illuminate\Support\Str::plural('report', $up)); ?> &middot; <?php echo e($warn); ?> <?php echo e(\Illuminate\Support\Str::plural('warning', $warn)); ?></span>
                                    <?php if($autoSuspendAfter > 0): ?><span class="ll-muted">(auto-suspend at <?php echo e($autoSuspendAfter); ?>)</span><?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <?php if($report->status === 'resolved'): ?>
                                <p class="rp-outcome">
                                    <strong><?php echo e(['none' => 'Closed, no action on the member', 'warn' => 'Member was warned', 'suspend' => 'Member was suspended'][$report->action_taken] ?? 'Resolved'); ?></strong>
                                    <?php if($report->admin_note): ?> &middot; &ldquo;<?php echo e($report->admin_note); ?>&rdquo; <?php endif; ?>
                                    <?php if($report->resolved_at): ?><span class="ll-muted"> &middot; <?php echo e($report->resolved_at->diffForHumans()); ?></span><?php endif; ?>
                                </p>
                            <?php elseif($report->status === 'dismissed'): ?>
                                <p class="rp-outcome muted"><strong>Dismissed</strong> &middot; not a valid complaint</p>
                            <?php endif; ?>

                            <footer class="rp-foot">
                                <div class="rp-actions">
                                    <?php if($report->status === 'pending'): ?>
                                        <button type="button" class="rp-btn primary" data-rp-toggle="resolve-<?php echo e($report->id); ?>" aria-expanded="false" aria-controls="resolve-<?php echo e($report->id); ?>">Resolve&hellip;</button>
                                        <form method="POST" action="<?php echo e(route('admin.reports.dismiss', $report->id)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="rp-btn">Dismiss</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" action="<?php echo e(route('admin.reports.delete', $report->id)); ?>" class="rp-delete" onsubmit="return confirm('Delete this report for good?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="rp-btn danger">Delete</button>
                                    </form>
                                </div>

                                <?php if($report->status === 'pending'): ?>
                                    <div class="rp-resolve-panel" id="resolve-<?php echo e($report->id); ?>" hidden>
                                        <form method="POST" action="<?php echo e(route('admin.reports.resolve', $report->id)); ?>" class="rp-resolve-form">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

                                            <fieldset class="rp-choices">
                                                <legend>What should happen to <?php echo e($reported->name ?? 'the member'); ?>?</legend>
                                                <label class="rp-choice"><input type="radio" name="action" value="none" checked>
                                                    <span><strong>No action</strong><small>The complaint is valid, but nothing happens to the member.</small></span></label>
                                                <label class="rp-choice"><input type="radio" name="action" value="warn">
                                                    <span><strong>Send a warning</strong><small>The member is warned and told why.</small></span></label>
                                                <label class="rp-choice"><input type="radio" name="action" value="suspend">
                                                    <span><strong>Suspend the account</strong><small>Choose a reason and how long below.</small></span></label>
                                            </fieldset>

                                            <div class="rp-suspend-fields" hidden>
                                                <label>Reason
                                                    <select name="reason">
                                                        <?php $__currentLoopData = \App\Support\Suspension::REASONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e($key === 'rules' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </label>
                                                <label>For how long
                                                    <select name="duration">
                                                        <?php $__currentLoopData = \App\Support\Suspension::OPTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>" <?php echo e($key === '1w' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </label>
                                            </div>

                                            <label class="rp-note"><span>Note <span class="ll-muted" data-note-hint>(kept on the report, optional)</span></span>
                                                <textarea name="note" rows="2" maxlength="500" placeholder="Optional"></textarea>
                                            </label>

                                            <button type="submit" class="rp-btn primary">Confirm</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </footer>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ll-card rp-empty">
                            <?php if($search !== ''): ?>
                                <strong>No reports match &ldquo;<?php echo e($search); ?>&rdquo;.</strong>
                            <?php elseif($statusFilter === 'pending'): ?>
                                <strong>You're all caught up.</strong>
                                <span class="ll-muted">No reports are waiting for review.</span>
                            <?php else: ?>
                                <strong>No reports here yet.</strong>
                                <span class="ll-muted">When a member reports someone in the app, it shows up here.</span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php echo e($reports->links('vendor.pagination.admin')); ?>

                </div>
            </div>
        </section>
    </main>
</div>


<script>
    // Open / close a report's Resolve panel.
    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-rp-toggle]');
        if (!button) return;

        var panel = document.getElementById(button.getAttribute('data-rp-toggle'));
        var opening = panel.hidden;
        panel.hidden = !opening;
        button.setAttribute('aria-expanded', opening ? 'true' : 'false');
        button.textContent = opening ? 'Close' : 'Resolve\u2026';
        button.classList.toggle('open', opening);
    });

    document.addEventListener('change', function (event) {
        var form = event.target.closest('.rp-resolve-form');
        if (!form) return;

        var action = form.querySelector('input[name=action]:checked').value;
        var other = action === 'suspend' && form.querySelector('select[name=reason]').value === 'other';
        var note = form.querySelector('textarea[name=note]');

        form.querySelector('.rp-suspend-fields').hidden = action !== 'suspend';
        note.required = other;
        form.querySelector('[data-note-hint]').textContent = other
            ? '(required: explain the reason)'
            : (action === 'none' ? '(kept on the report, optional)' : '(shown to the member, optional)');
    });
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/reports.blade.php ENDPATH**/ ?>