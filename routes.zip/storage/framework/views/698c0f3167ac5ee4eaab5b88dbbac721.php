<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Security</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Security</h1>
                <p>Every sign-in needs your password and a code sent to your email.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">
                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="sec-grid">

                        
                        <div class="ll-card">
                            <div class="ll-row between">
                                <h3>Email sign-in code</h3>
                                <span class="ll-badge <?php echo e($enabled ? 'completed' : 'pending'); ?>"><?php echo e($enabled ? 'Always on' : 'Off'); ?></span>
                            </div>
                            <?php if($enabled): ?>
                                <div class="sec-ok">
                                    After your password, a 6-digit code is emailed to <strong><?php echo e($maskedEmail); ?></strong>. It works once and expires in <?php echo e(\App\Support\EmailOtp::TTL_MINUTES); ?> minutes. After 5 wrong tries it is cancelled.
                                </div>
                                <p class="ll-muted">Make sure you can read that mailbox. Forgot your password? Use <em>Forgot password</em> on the login page: it also sends a code to this email.</p>
                            <?php else: ?>
                                <div class="sec-warn">The email code is switched off in the server settings (<code>learnloop.admin_email_otp</code>). Anyone with your password can sign in.</div>
                            <?php endif; ?>
                        </div>

                        
                        <div class="ll-card">
                            <div class="ll-row between">
                                <h3>Trusted browsers</h3>
                                <?php if($devices->count() > 1): ?>
                                    <form method="POST" action="<?php echo e(route('admin.security.devices.clear')); ?>" onsubmit="return confirm('Stop trusting all browsers?');">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="table-btn">Remove all</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <p class="ll-muted">Browsers where you ticked “Trust this browser” skip the code for <?php echo e(\App\Support\AdminDevices::DAYS); ?> days. Remove any you do not recognise.</p>

                            <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="ll-row between" style="padding:10px 0; border-top:1px solid rgba(0,0,0,.07);">
                                    <div>
                                        <strong><?php echo e($device->label ?? 'Browser'); ?></strong>
                                        <?php if($currentDevice === $device->id): ?><span class="ll-badge completed">This browser</span><?php endif; ?>
                                        <div class="ll-muted" style="font-size:12.5px;">
                                            <?php echo e($device->ip); ?> &middot; last used <?php echo e(\Illuminate\Support\Carbon::parse($device->last_used_at)->diffForHumans()); ?>

                                            &middot; trusted until <?php echo e(\Illuminate\Support\Carbon::parse($device->expires_at)->format('M j')); ?>

                                        </div>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('admin.security.devices.remove', $device->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="delete-btn">Remove</button>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">No trusted browsers. You will get a code every time you sign in.</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="ll-card">
                            <h3>Recent sign-in activity</h3>
                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div style="padding:8px 0; border-top:1px solid rgba(0,0,0,.07); font-size:13.5px;">
                                    <?php echo e($event->description); ?>

                                    <span class="ll-muted">&middot; <?php echo e($event->created_at->diffForHumans()); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="ll-muted">Nothing yet.</p>
                            <?php endif; ?>
                            <p class="ll-muted" style="margin-top:10px;">Everything else you do is in <a href="<?php echo e(route('admin.activity')); ?>">Activity</a>.</p>
                        </div>

                        
                        <div class="ll-card">
                            <h3>Other protection already in place</h3>
                            <ul class="ll-muted" style="padding-left:18px; line-height:1.8;">
                                <li>Admin login locks for a minute after 5 wrong tries.</li>
                                <li>Only active admin accounts can sign in to this panel.</li>
                                <li>Changing a password with an email code signs out every phone and trusted browser.</li>
                                <li>App login and sign-up are rate limited.</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/security.blade.php ENDPATH**/ ?>