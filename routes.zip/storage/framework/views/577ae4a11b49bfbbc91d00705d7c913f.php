<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - Settings</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<?php
    $tabs = [
        'account' => 'Account',
        'password' => 'Password',
        'security' => 'Security',
        'notifications' => 'Notifications',
    ];
    $emailChangeOpen = $errors->has('email_confirmation') || $errors->has('current_password') && $tab === 'account';
?>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">

        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>Settings</h1>
                <p>Your account, password, sign-in security and email alerts.</p>
            </div>
        </header>

        <section class="settings-page">
            <div class="settings-scroll-area">

                <?php if(session('success')): ?>
                    <div class="ll-flash st-flash"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if($errors->has('image')): ?>
                    <div class="ll-flash error st-flash"><?php echo e($errors->first('image')); ?></div>
                <?php endif; ?>
                <?php if($errors->has('notifications')): ?>
                    <div class="ll-flash error st-flash"><?php echo e($errors->first('notifications')); ?></div>
                <?php endif; ?>

                <div class="st-layout">

                    
                    <nav class="st-tabs" aria-label="Settings sections">
                        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.settings', ['tab' => $key])); ?>"
                               class="st-tab <?php echo e($tab === $key ? 'active' : ''); ?>"
                               data-tab="<?php echo e($key); ?>">
                                <?php echo e($label); ?>

                                <?php if($key === 'security' && ! $otpEnabled): ?>
                                    <span class="st-dot warn" title="The email code is switched off"></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>

                    <div class="st-panels">

                        
                        <div class="st-panel" data-panel="account" <?php if($tab !== 'account'): ?> hidden <?php endif; ?>>

                            <div class="settings-card st-me">
                                
                                <div class="st-banner" <?php if($me->banner_url): ?> style="background-image:url('<?php echo e($me->banner_url); ?>')" <?php endif; ?>>
                                    <div class="st-banner-actions">
                                        <form method="POST" action="<?php echo e(route('admin.settings.picture', 'banner')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="tab" value="account">
                                            <label class="st-pick">
                                                <?php echo e($me->banner_path ? 'Change banner' : 'Add banner'); ?>

                                                <input type="file" name="image" accept="image/jpeg,image/png,image/webp" onchange="this.form.submit()">
                                            </label>
                                        </form>
                                        <?php if($me->banner_path): ?>
                                            <form method="POST" action="<?php echo e(route('admin.settings.picture.remove', 'banner')); ?>" onsubmit="return confirm('Remove your banner?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="st-pick danger">Remove</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="st-me-body">
                                    <?php echo $__env->make('partials.avatar', ['user' => $me, 'class' => 'st-avatar', 'letters' => 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <div class="st-me-text">
                                        <h2><?php echo e($me->name); ?></h2>
                                        <p><?php echo e($me->email); ?></p>
                                        <div class="st-me-meta">
                                            <span class="ll-badge completed">Administrator</span>
                                            <span>Member since <?php echo e($me->created_at?->format('M j, Y')); ?></span>
                                        </div>
                                    </div>
                                    <div class="st-avatar-actions">
                                        <form method="POST" action="<?php echo e(route('admin.settings.picture', 'avatar')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="tab" value="account">
                                            <label class="st-pick dark">
                                                <?php echo e($me->avatar_path ? 'Change picture' : 'Add picture'); ?>

                                                <input type="file" name="image" accept="image/jpeg,image/png,image/webp" onchange="this.form.submit()">
                                            </label>
                                        </form>
                                        <?php if($me->avatar_path): ?>
                                            <form method="POST" action="<?php echo e(route('admin.settings.picture.remove', 'avatar')); ?>" onsubmit="return confirm('Remove your profile picture?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="st-pick dark danger">Remove</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <p class="st-hint" style="margin:10px 0 0;">JPG, PNG or WebP, up to 5 MB. A wide picture works best for the banner.</p>
                            </div>

                            <div class="settings-card">
                                <div class="settings-card-header">
                                    <span class="section-label">ACCOUNT</span>
                                    <h2>Your details</h2>
                                    <p>The name shown in the panel and the email address that receives your sign-in codes.</p>
                                </div>

                                <form class="st-form" method="POST" action="<?php echo e(route('admin.settings.account')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="tab" value="account">

                                    <div class="st-field">
                                        <label for="st-name">Name</label>
                                        <input id="st-name" name="name" type="text" maxlength="255" autocomplete="name"
                                               value="<?php echo e(old('name', $me->name)); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="st-field">
                                        <label for="st-email">Email</label>
                                        <input id="st-email" name="email" type="email" maxlength="255" autocomplete="email"
                                               value="<?php echo e(old('email', $me->email)); ?>" data-original="<?php echo e($me->email); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="st-reveal" id="st-email-change" <?php if(! $emailChangeOpen): ?> hidden <?php endif; ?>>
                                        <div class="settings-warning">
                                            Sign-in codes are emailed to this address. Check it carefully: a wrong address would lock you out.
                                        </div>

                                        <div class="st-field">
                                            <label for="st-email2">Type the new email again</label>
                                            <input id="st-email2" name="email_confirmation" type="email" autocomplete="off"
                                                   value="<?php echo e(old('email_confirmation')); ?>">
                                            <?php $__errorArgs = ['email_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="st-field">
                                            <label for="st-email-pw">Your password</label>
                                            <input id="st-email-pw" name="current_password" type="password" autocomplete="current-password"
                                                   placeholder="Needed to change the email">
                                            <?php if($tab === 'account'): ?>
                                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="settings-actions">
                                        <button type="submit" class="settings-save-btn">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        
                        <div class="st-panel" data-panel="password" <?php if($tab !== 'password'): ?> hidden <?php endif; ?>>
                            <div class="settings-card">
                                <div class="settings-card-header">
                                    <span class="section-label">PASSWORD</span>
                                    <h2>Change password</h2>
                                    <p>
                                        <?php if($lastPasswordChange): ?>
                                            Last changed <?php echo e($lastPasswordChange->diffForHumans()); ?>.
                                        <?php else: ?>
                                            Use a password you do not use anywhere else.
                                        <?php endif; ?>
                                    </p>
                                </div>

                                <form class="st-form" method="POST" action="<?php echo e(route('admin.settings.password')); ?>" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="tab" value="password">

                                    <div class="st-field">
                                        <label for="st-current">Current password</label>
                                        <div class="st-pw">
                                            <input id="st-current" name="current_password" type="password" autocomplete="current-password" required>
                                            <button type="button" class="st-eye" data-toggle-pw="st-current">Show</button>
                                        </div>
                                        <?php if($tab === 'password'): ?>
                                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php endif; ?>
                                    </div>

                                    <div class="st-field">
                                        <label for="st-new">New password</label>
                                        <div class="st-pw">
                                            <input id="st-new" name="password" type="password" autocomplete="new-password" minlength="8" required>
                                            <button type="button" class="st-eye" data-toggle-pw="st-new">Show</button>
                                        </div>
                                        <div class="st-meter" aria-hidden="true"><i id="st-meter-bar"></i></div>
                                        <span class="st-hint" id="st-meter-text">At least 8 characters. Longer is stronger.</span>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="st-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="st-field">
                                        <label for="st-confirm">Confirm new password</label>
                                        <div class="st-pw">
                                            <input id="st-confirm" name="password_confirmation" type="password" autocomplete="new-password" required>
                                            <button type="button" class="st-eye" data-toggle-pw="st-confirm">Show</button>
                                        </div>
                                        <span class="st-hint" id="st-match-text"></span>
                                    </div>

                                    <div class="settings-warning">
                                        After a change, phones and trusted browsers are signed out and the next sign-in asks for an email code.
                                    </div>

                                    <div class="settings-actions" style="margin-top:14px;">
                                        <button type="submit" class="settings-save-btn">Update password</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        
                        <div class="st-panel" data-panel="security" <?php if($tab !== 'security'): ?> hidden <?php endif; ?>>

                            <div class="settings-card">
                                <div class="st-between">
                                    <div class="settings-card-header" style="margin-bottom:0;">
                                        <span class="section-label">SECURITY</span>
                                        <h2>Email sign-in code</h2>
                                    </div>
                                    <span class="ll-badge <?php echo e($otpEnabled ? 'completed' : 'pending'); ?>"><?php echo e($otpEnabled ? 'Always on' : 'Off'); ?></span>
                                </div>

                                <?php if($otpEnabled): ?>
                                    <div class="sec-ok" style="margin-top:14px;">
                                        After your password, a 6-digit code is emailed to <strong><?php echo e($maskedEmail); ?></strong>.
                                        It works once and expires in <?php echo e(\App\Support\EmailOtp::TTL_MINUTES); ?> minutes. After 5 wrong tries it is cancelled.
                                    </div>
                                    <p class="ll-muted" style="margin-top:10px;">
                                        Make sure you can read that mailbox. Forgot your password? Use <em>Forgot password</em> on the login page: it also sends a code to this email.
                                    </p>
                                <?php else: ?>
                                    <div class="sec-warn" style="margin-top:14px;">
                                        The email code is switched off in the server settings (<code>learnloop.admin_email_otp</code>). Anyone with your password can sign in.
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="settings-card">
                                <div class="st-between">
                                    <div class="settings-card-header" style="margin-bottom:0;">
                                        <span class="section-label">DEVICES</span>
                                        <h2>Trusted browsers</h2>
                                    </div>
                                    <?php if($devices->count() > 1): ?>
                                        <form method="POST" action="<?php echo e(route('admin.security.devices.clear')); ?>" onsubmit="return confirm('Stop trusting all browsers?');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="table-btn">Remove all</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                                <p class="ll-muted" style="margin:8px 0 6px;">
                                    Browsers where you ticked “Trust this browser” skip the code for <?php echo e(\App\Support\AdminDevices::DAYS); ?> days. Remove any you do not recognise.
                                </p>

                                <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="st-device">
                                        <div>
                                            <strong><?php echo e($device->label ?? 'Browser'); ?></strong>
                                            <?php if($currentDevice === $device->id): ?><span class="ll-badge completed">This browser</span><?php endif; ?>
                                            <div class="ll-muted">
                                                <?php echo e($device->ip); ?> &middot; last used <?php echo e(\Illuminate\Support\Carbon::parse($device->last_used_at)->diffForHumans()); ?>

                                                &middot; trusted until <?php echo e(\Illuminate\Support\Carbon::parse($device->expires_at)->format('M j')); ?>

                                            </div>
                                        </div>
                                        <form method="POST" action="<?php echo e(route('admin.security.devices.remove', $device->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="delete-btn">Remove</button>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="ll-muted st-empty">No trusted browsers. You will get a code every time you sign in.</p>
                                <?php endif; ?>
                            </div>

                            <div class="settings-card">
                                <div class="settings-card-header">
                                    <span class="section-label">HISTORY</span>
                                    <h2>Recent sign-in activity</h2>
                                </div>

                                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="st-event">
                                        <span class="st-dot <?php echo e($event->action === 'admin.verify_failed' ? 'bad' : 'ok'); ?>"></span>
                                        <span><?php echo e($event->description); ?></span>
                                        <span class="ll-muted"><?php echo e($event->created_at->diffForHumans()); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="ll-muted st-empty">Nothing yet.</p>
                                <?php endif; ?>

                                <p class="ll-muted" style="margin-top:12px;">Everything else you do is in <a href="<?php echo e(route('admin.activity')); ?>">Activity Log</a>.</p>
                            </div>

                            <div class="settings-card">
                                <div class="settings-card-header">
                                    <span class="section-label">PROTECTION</span>
                                    <h2>Already in place</h2>
                                </div>
                                <ul class="st-list">
                                    <li>Admin login locks for a minute after 5 wrong tries.</li>
                                    <li>Only active admin accounts can sign in to this panel.</li>
                                    <li>Changing a password signs out every phone and trusted browser.</li>
                                    <li>App login and sign-up are rate limited.</li>
                                </ul>
                            </div>
                        </div>

                        
                        <div class="st-panel" data-panel="notifications" <?php if($tab !== 'notifications'): ?> hidden <?php endif; ?>>
                            <div class="settings-card">
                                <div class="settings-card-header">
                                    <span class="section-label">ALERTS</span>
                                    <h2>Email alerts</h2>
                                    <p>Work that needs you always shows in the sidebar and on the <a href="<?php echo e(route('admin.notifications')); ?>">Notifications</a> page. Switch on email to hear about it without opening the panel.</p>
                                </div>

                                <?php if (! ($mailSends)): ?>
                                    <div class="sec-warn" style="margin-bottom:6px;">
                                        This server is not set up to send email yet (mail is set to <code><?php echo e(config('mail.default')); ?></code>), so these emails are only written to the log.
                                        Set <code>MAIL_MAILER</code> and the mail settings in <code>.env</code> to send them for real.
                                    </div>
                                <?php endif; ?>

                                <form method="POST" action="<?php echo e(route('admin.settings.notifications')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="tab" value="notifications">

                                    <div class="settings-option">
                                        <div>
                                            <h3>New reports</h3>
                                            <p>Email me when a member reports a listing or another member.</p>
                                        </div>
                                        <label class="toggle">
                                            <input type="hidden" name="email_report_alerts" value="0">
                                            <input type="checkbox" name="email_report_alerts" value="1" <?php echo e($prefs['email_report_alerts'] ? 'checked' : ''); ?>>
                                            <span class="toggle-slider"></span>
                                        </label>
                                    </div>

                                    <div class="settings-option">
                                        <div>
                                            <h3>Account recovery requests</h3>
                                            <p>Email me when a suspended member asks to be reactivated.</p>
                                        </div>
                                        <label class="toggle">
                                            <input type="hidden" name="email_appeal_alerts" value="0">
                                            <input type="checkbox" name="email_appeal_alerts" value="1" <?php echo e($prefs['email_appeal_alerts'] ? 'checked' : ''); ?>>
                                            <span class="toggle-slider"></span>
                                        </label>
                                    </div>

                                    <div class="settings-actions" style="margin-top:6px;">
                                        <button type="submit" class="settings-save-btn">Save preferences</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </section>
    </main>
</div>

<script>
(function () {
    // ---- Tabs: switch without reloading, keep the address in step so refresh and links work ----
    var tabs = document.querySelectorAll('.st-tab');
    var panels = document.querySelectorAll('.st-panel');

    function show(name, push) {
        tabs.forEach(function (t) { t.classList.toggle('active', t.dataset.tab === name); });
        panels.forEach(function (p) { p.hidden = p.dataset.panel !== name; });
        if (push && window.history && history.replaceState) {
            history.replaceState(null, '', '<?php echo e(route('admin.settings')); ?>?tab=' + name);
        }
    }
    tabs.forEach(function (t) {
        t.addEventListener('click', function (e) { e.preventDefault(); show(t.dataset.tab, true); });
    });

    // ---- Email: ask for the extra confirmation only when the address is being changed ----
    var email = document.getElementById('st-email');
    var reveal = document.getElementById('st-email-change');
    if (email && reveal) {
        email.addEventListener('input', function () {
            var changed = email.value.trim().toLowerCase() !== email.dataset.original.toLowerCase();
            reveal.hidden = !changed;
        });
    }

    // ---- Password: show / hide ----
    document.querySelectorAll('[data-toggle-pw]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.dataset.togglePw);
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Hide' : 'Show';
        });
    });

    // ---- Password: strength hint and match check ----
    var pw = document.getElementById('st-new');
    var confirm = document.getElementById('st-confirm');
    var bar = document.getElementById('st-meter-bar');
    var text = document.getElementById('st-meter-text');
    var match = document.getElementById('st-match-text');

    function score(v) {
        var s = 0;
        if (v.length >= 8) s++;
        if (v.length >= 12) s++;
        if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++;
        if (/\d/.test(v)) s++;
        if (/[^A-Za-z0-9]/.test(v)) s++;
        return s;
    }
    var labels = ['Too short', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
    var colors = ['#B14D48', '#B14D48', '#B78334', '#8FD64C', '#4E8A43', '#4E8A43'];

    function update() {
        if (pw && bar) {
            var v = pw.value, s = v.length ? score(v) : 0;
            bar.style.width = (v.length ? Math.max(12, s * 20) : 0) + '%';
            bar.style.background = colors[s];
            text.textContent = v.length ? labels[s] : 'At least 8 characters. Longer is stronger.';
        }
        if (confirm && match) {
            if (!confirm.value.length) { match.textContent = ''; match.className = 'st-hint'; }
            else if (confirm.value === pw.value) { match.textContent = 'Passwords match.'; match.className = 'st-hint ok'; }
            else { match.textContent = 'Passwords do not match yet.'; match.className = 'st-hint bad'; }
        }
    }
    if (pw) pw.addEventListener('input', update);
    if (confirm) confirm.addEventListener('input', update);
})();
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/settings.blade.php ENDPATH**/ ?>