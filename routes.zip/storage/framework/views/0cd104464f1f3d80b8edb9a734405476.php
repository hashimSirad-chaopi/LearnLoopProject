<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLoop - User Management</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.admin-filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="admin-container">

    <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content" data-live>

        <header class="top-header">
            <div class="header-left">
                <span class="header-label">ADMIN PANEL</span>
                <h1>User Management</h1>
                <p>Find members, review their accounts, and suspend or reactivate them.</p>
            </div>
        </header>

        <section class="users-page">
            <div class="ll-scroll">
                <div class="ll-page">

                    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php if($errors->any()): ?>
                        <div class="um-alert"><?php echo e($errors->first()); ?></div>
                    <?php endif; ?>

                    
                    <div class="um-stats">
                        <a class="um-stat <?php echo e($status === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users', array_filter(['search' => $search]))); ?>">
                            <span class="um-stat-label">All accounts</span>
                            <strong><?php echo e(number_format($counts['all'])); ?></strong>
                        </a>
                        <a class="um-stat <?php echo e($status === 'active' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users', array_filter(['search' => $search, 'status' => 'active']))); ?>">
                            <span class="um-stat-label">Active</span>
                            <strong><?php echo e(number_format($counts['active'])); ?></strong>
                        </a>
                        <a class="um-stat <?php echo e($status === 'offline' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users', array_filter(['search' => $search, 'status' => 'offline']))); ?>">
                            <span class="um-stat-label">Offline</span>
                            <strong><?php echo e(number_format($counts['offline'])); ?></strong>
                        </a>
                        <a class="um-stat <?php echo e($status === 'suspended' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users', array_filter(['search' => $search, 'status' => 'suspended']))); ?>">
                            <span class="um-stat-label">Suspended</span>
                            <strong><?php echo e(number_format($counts['suspended'])); ?></strong>
                        </a>
                        <div class="um-stat plain">
                            <span class="um-stat-label">Joined this week</span>
                            <strong><?php echo e(number_format($counts['week'])); ?></strong>
                        </div>
                    </div>

                    
                    <div class="ll-toolbar">
                        <form method="GET" action="<?php echo e(route('admin.users')); ?>" class="ll-search">
                            <?php if($status !== 'all'): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
                            <?php if($sort !== 'created_at' || $dir !== 'desc'): ?>
                                <input type="hidden" name="sort" value="<?php echo e($sort); ?>">
                                <input type="hidden" name="dir" value="<?php echo e($dir); ?>">
                            <?php endif; ?>
                            <input type="search" name="search" value="<?php echo e($search); ?>" placeholder="Search by name or email" aria-label="Search users">
                            <button type="submit" class="table-btn">Search</button>
                            <?php if($search !== ''): ?>
                                <a href="<?php echo e(route('admin.users', array_filter(['status' => $status !== 'all' ? $status : null]))); ?>" class="table-btn ll-link">Clear</a>
                            <?php endif; ?>
                        </form>
                        <span style="display:flex;gap:8px;align-items:center;">
                            <a href="<?php echo e(route('admin.users.export', array_filter(['search' => $search, 'status' => $status !== 'all' ? $status : null]))); ?>" class="table-btn ll-link">Export CSV</a>
                            <a href="<?php echo e(route('admin.users.create')); ?>" class="settings-save-btn ll-link">+ Add user</a>
                        </span>
                    </div>

                    <span class="ll-muted">
                        <?php echo e($users->total()); ?> <?php echo e(\Illuminate\Support\Str::plural('account', $users->total())); ?>

                        <?php if($status !== 'all'): ?> &middot; <?php echo e($status); ?> only <?php endif; ?>
                        <?php if($search !== ''): ?> &middot; matching &ldquo;<?php echo e($search); ?>&rdquo; <?php endif; ?>
                    </span>

                    
                    <?php if($users->isNotEmpty()): ?>
                        <form id="bulk-users" method="POST" action="<?php echo e(route('admin.users.bulk')); ?>" class="bulk-bar">
                            <?php echo csrf_field(); ?>
                            <label class="bulk-all"><input type="checkbox" data-select-all="bulk-users"> Select all on this page</label>
                            <span class="bulk-count"></span>
                            <span class="bulk-actions">
                                <select name="duration" class="lr-select" aria-label="Suspend selected members for">
                                    <?php $__currentLoopData = \App\Support\Suspension::OPTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key === '1w' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="reason" class="lr-select" aria-label="Reason for suspending">
                                    <?php $__currentLoopData = \App\Support\Suspension::REASONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key === 'rules' ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="text" name="note" class="lr-select" maxlength="500" placeholder='Details (required for "Other")' aria-label="Suspension details">
                                <button type="submit" name="bulk" value="suspend" class="table-btn" onclick="return confirm('Suspend the selected members for the chosen time? They will be signed out of the app and told by notification.');">Suspend selected</button>
                                <button type="submit" name="bulk" value="activate" class="table-btn" onclick="return confirm('Reactivate the selected members?');">Reactivate selected</button>
                            </span>
                        </form>
                    <?php endif; ?>

                    
                    <div class="users-table-container um-table-wrap">
                        <table class="users-table um-table">
                            <thead>
                                <tr>
                                    <th class="um-check"></th>
                                    <?php $__currentLoopData = ['name' => 'Member', 'role' => 'Role', 'status' => 'Status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th>
                                            <a class="th-sort <?php echo e($sort === $col ? 'active' : ''); ?>"
                                               href="<?php echo e(route('admin.users', array_filter(['search' => $search, 'status' => $status !== 'all' ? $status : null, 'sort' => $col, 'dir' => ($sort === $col && $dir === 'asc') ? 'desc' : 'asc']))); ?>">
                                                <?php echo e($label); ?><span class="arrow"><?php echo e($sort === $col ? ($dir === 'asc' ? '▲' : '▼') : '↕'); ?></span>
                                            </a>
                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th class="um-hide-sm">Listings</th>
                                    <th class="um-hide-sm">Reports</th>
                                    <th class="um-hide-sm">
                                        <a class="th-sort <?php echo e($sort === 'created_at' ? 'active' : ''); ?>"
                                           href="<?php echo e(route('admin.users', array_filter(['search' => $search, 'status' => $status !== 'all' ? $status : null, 'sort' => 'created_at', 'dir' => ($sort === 'created_at' && $dir === 'asc') ? 'desc' : 'asc']))); ?>">
                                            Joined<span class="arrow"><?php echo e($sort === 'created_at' ? ($dir === 'asc' ? '▲' : '▼') : '↕'); ?></span>
                                        </a>
                                    </th>
                                    <th class="um-actions-col">Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php ($isSelf = $user->id === auth()->id()); ?>
                                    <?php ($locked = $isSelf || $user->role === 'admin'); ?>
                                    <?php ($reports = (int) ($reportCounts[$user->id] ?? 0)); ?>
                                    <tr>
                                        <td class="um-check">
                                            <?php if (! ($locked)): ?>
                                                <input type="checkbox" name="ids[]" value="<?php echo e($user->id); ?>" form="bulk-users" class="bulk-check" aria-label="Select <?php echo e($user->name); ?>">
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <a class="user-cell um-member" href="<?php echo e(route('admin.users.show', $user->id)); ?>">
                                                <?php echo $__env->make('partials.avatar', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                <span class="um-member-text">
                                                    <strong><?php echo e($user->name); ?> <?php if($isSelf): ?><em class="um-you">you</em><?php endif; ?></strong>
                                                    <small><?php echo e($user->email); ?></small>
                                                </span>
                                            </a>
                                        </td>

                                        <td><span class="role-badge"><?php echo e(ucfirst($user->role ?? 'user')); ?></span></td>

                                        <td>
                                            <?php if($user->status === 'suspended'): ?>
                                                <span class="status-badge suspended-status">Suspended</span>
                                                <small class="lr-until"><?php echo e($user->suspended_until ? 'until '.$user->suspended_until->format('M j, Y g:i A') : 'until reactivated'); ?></small>
                                                <?php if($why = \App\Support\Suspension::describe($user->suspension_reason, $user->suspension_note)): ?>
                                                    <small class="lr-until" title="<?php echo e($why); ?>">Reason: <?php echo e(\Illuminate\Support\Str::limit($why, 48)); ?></small>
                                                <?php endif; ?>
                                            <?php elseif($user->isOnline()): ?>
                                                <span class="status-badge active-status">Active</span>
                                                <small class="lr-until">online now</small>
                                            <?php else: ?>
                                                <span class="status-badge offline-status">Offline</span>
                                                <small class="lr-until"><?php echo e($user->last_seen_at ? 'last seen '.$user->last_seen_at->diffForHumans() : 'not seen yet'); ?></small>
                                            <?php endif; ?>
                                        </td>

                                        <td class="um-hide-sm"><?php echo e((int) ($listingCounts[$user->id] ?? 0)); ?></td>
                                        <td class="um-hide-sm">
                                            <?php if($reports > 0): ?><span class="um-flag" title="Reports against this member that an admin upheld"><?php echo e($reports); ?></span><?php else: ?><span class="ll-muted">0</span><?php endif; ?>
                                        </td>
                                        <td class="um-hide-sm"><?php echo e($user->created_at?->format('M j, Y')); ?></td>

                                        <td class="um-actions-col">
                                            <div class="um-actions">
                                                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="um-btn" title="View profile" aria-label="View <?php echo e($user->name); ?>">
                                                    <?php echo $__env->make('partials.icon', ['name' => 'eye'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span class="label">View</span>
                                                </a>
                                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="um-btn" title="Edit details" aria-label="Edit <?php echo e($user->name); ?>">
                                                    <?php echo $__env->make('partials.icon', ['name' => 'edit'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span class="label">Edit</span>
                                                </a>
                                                <?php if (! ($locked)): ?>
                                                    <?php if($user->status === 'suspended'): ?>
                                                        <form method="POST" action="<?php echo e(route('admin.users.activate', $user->id)); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                            <button type="submit" class="um-btn good" title="Reactivate account" aria-label="Reactivate <?php echo e($user->name); ?>">
                                                                <?php echo $__env->make('partials.icon', ['name' => 'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span class="label">Reactivate</span>
                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <button type="button" class="um-btn warn" title="Suspend account" aria-label="Suspend <?php echo e($user->name); ?>"
                                                                data-suspend-open data-suspend-url="<?php echo e(route('admin.users.suspend', $user->id)); ?>" data-suspend-name="<?php echo e($user->name); ?>">
                                                            <?php echo $__env->make('partials.icon', ['name' => 'ban'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span class="label">Suspend</span>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="empty-users">
                                            <?php echo e($search !== '' || $status !== 'all' ? 'No accounts match these filters.' : 'No users yet.'); ?>

                                            <?php if($search !== '' || $status !== 'all'): ?>
                                                <a href="<?php echo e(route('admin.users')); ?>">Clear filters</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($users->links('vendor.pagination.admin')); ?>


                </div>
            </div>
        </section>
    </main>
</div>

<?php echo $__env->make('partials.suspend-dialog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\LearnLoopProject - Copy\resources\views/admin/users.blade.php ENDPATH**/ ?>